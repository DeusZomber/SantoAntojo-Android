# Santo Antojo Android 1.3 · Campañas con IA

## Incluido en este ZIP
- Aplicación Android (fuente) con punto de venta e inventario sin conexión, fotografías y datos en el dispositivo.
- Panel de campañas: cargar foto, seleccionar producto, generar texto, editar texto, crear variante gráfica por IA, previsualizar, guardar borrador, aprobar y solicitar programación en Facebook/Instagram.
- Puente HTTPS nativo (`MainActivity.java`). Evita el problema de CORS de una aplicación WebView cargada desde `file:///android_asset` sin dar acceso de red libre al JavaScript.
- Servidor Node 20+ (`server/campaign-server.mjs`) con OpenAI Responses (texto estructurado), OpenAI Images Edits, guardado de medios y API de programación Metricool.
- Pruebas del servidor simulando proveedores (`node --test tests/campaign.test.mjs`).

## No está activado automáticamente
- Este paquete NO es APK compilado. Se necesita Android Studio con JDK 17, Android SDK 35 y Gradle 8.7. En este entorno no hay SDK Android disponible para realizar una compilación y prueba real.
- NO se ha desplegado ningún servidor ni se ha usado una clave OpenAI real.
- NO se ha publicado contenido en redes ni probado el API real de Metricool.
- Para programar desde la app, Metricool exige un **plan Advanced o Custom**, token API y cuentas conectadas; conectar la cuenta en ChatGPT no cede su token al APK.
- No hay video automático, voces, ni publicación instantánea. El módulo prepara una imagen y programa para fecha futura; las redes pueden imponer restricciones.
- La edición por IA toma la foto como referencia, pero no puede garantizar que conserve exactamente las etiquetas, la marca, el envase ni los ingredientes. Revisar siempre la imagen antes de aprobar.

## Configurar servidor (técnico/administrador)
1. Alquila o configura un servicio Node 20+ con **dominio HTTPS público** (reverse proxy como Caddy/Nginx; el proceso Node queda ligado al localhost por defecto). La app no acepta direcciones HTTP.
2. Establece variables de entorno privadas según `server/.env.example`. NO pegues credenciales reales en el ZIP ni en ChatGPT. Variables obligatorias para texto e imagen: `OPENAI_API_KEY`, `SANTO_CAMPAIGN_TOKEN` (código aleatorio diferente de OpenAI, longitud de 24 caracteres o más).
3. Para programación con imagen configura `PUBLIC_ORIGIN=https://tu-dominio-real.mx` y `MEDIA_DIR` en **almacenamiento persistente**: allí quedan públicas las fotos aprobadas por el usuario; protege acceso al servidor, copias de seguridad y acceso de escritura. `MEDIA_DIR` debe persistir tras despliegues; evita servidores sin almacenamiento persistente.
4. Para publicar por Metricool, configura también `METRICOOL_API_TOKEN`, `METRICOOL_USER_ID` y `METRICOOL_BLOG_ID` obtenidos en tu cuenta de Metricool con API permitida. ID de usuario y marca no son secretos, el token sí.
5. En carpeta raíz del proyecto, inicia `node server/campaign-server.mjs` detrás del proxy HTTPS. La respuesta GET `/health` expone únicamente indicadores booleanos de configuración y versión.
6. En el APK abre **Campañas con IA > ⚙ Servidor IA**, escribe únicamente el dominio HTTPS base y el `SANTO_CAMPAIGN_TOKEN` generado por ti. Nunca pegues la clave secreta de OpenAI ni el token Metricool en Android.
7. Selecciona un producto, sube imagen, genera texto. Opcionalmente crea una imagen con IA (cargo por uso), revísala, edita copy, elige redes y horario futuro y **confirma** la solicitud de programación.

### Crear un código de acceso seguro
En una terminal privada del servidor: `openssl rand -hex 32` (64 caracteres). Guárdalo como `SANTO_CAMPAIGN_TOKEN`; en Android escribe ese mismo código en Configuración de Servidor IA. No confundir con OpenAI API key ni ponerlo en archivos compartidos.

### Seguridad y operatividad
- Token de app separado de OpenAI/Metricool; cuota básica por día por proceso para `/campaign`, `/image` y `/schedule`. Para operar públicamente añade gateway, registro de auditoría sin secretos, backup de las fotografías, monitorización, límites por usuario y costos, rate limit centralizado y autenticación robusta. El servidor es una base funcional, no un producto comercial auditado.
- La foto se aloja en tu servidor y se vuelve accesible sin contraseña por una URL difícil de adivinar para que Metricool pueda recuperarla. No subas fotos privadas o que no desees alojar públicamente.
- El backend no programa si falla normalizar la imagen o no recibe `mediaId`. La compatibilidad final y permisos depende del plan y de cada red.
- La app marca el borrador como enviado al recibir respuesta satisfactoria; verificación real de publicación en Planner/Metricool sigue siendo necesaria.
- No se incluyó ningún certificado de firma privado. Para **actualizar el mismo APK instalado sin perder datos**, usa tu certificado de firma ORIGINAL y el mismo applicationId. Si no lo tienes, una APK nueva con otra firma no actualiza la instalación anterior.
- Antes de instalar cualquier APK actualizada realiza respaldo desde **Configurar > Respaldo**. No desinstales la app anterior; guarda el respaldo fuera del teléfono.

## Pruebas
- `node --check app/src/main/assets/app.js`
- `node --test tests/campaign.test.mjs` — pruebas locales con doble simulado de OpenAI y Metricool, sin enviar posts reales.
- `npm install && npm test` — también ejecuta el conjunto de pruebas de POS que requiere `jsdom`.
- `./gradlew assembleDebug` o en Android Studio `Build > Build APK(s)` después de instalar el SDK y configurar Gradle en la máquina de desarrollo.

## Fuentes oficiales
- https://developers.openai.com/api/docs/guides/structured-outputs
- https://developers.openai.com/api/reference/resources/images/methods/edit
- https://help.metricool.com/es/guia-basica-para-la-integracion-con-la-api-r97af
