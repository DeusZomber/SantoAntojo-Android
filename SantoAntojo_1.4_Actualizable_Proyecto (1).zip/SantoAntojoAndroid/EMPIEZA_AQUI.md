# Santo Antojo 1.4 — aplicación actualizable

## Qué cambia para ti

Después de compilar e instalar **una sola APK inicial**, las siguientes versiones podrán instalarse desde **Configurar > Actualizaciones** sin descargar proyectos ZIP.

- La app consulta un archivo `update.json` publicado en HTTPS. Con la dirección configurada, también lo revisa al iniciar sesión de administrador, como máximo una vez al día.
- Cuando existe una versión superior, solicita tu aprobación, descarga la APK dentro de la app y comprueba su hash SHA-256. Comprueba también el identificador del paquete y que el número de versión sea superior.
- Android muestra el instalador y pide confirmación; en el primer uso puede pedir permiso para instalar aplicaciones desde Santo Antojo. No puede instalarse silenciosamente.
- Si la actualización está **firmada con el mismo certificado que la versión instalada**, los datos de ventas, clientes e inventario se conservan. De todas formas, haz un respaldo JSON antes de actualizar.
- El POS puede seguir operando sin internet. Buscar y descargar actualizaciones requiere internet.

## Una sola preparación para activar las actualizaciones

1. Crea un repositorio **público** de GitHub para distribuir las APK sin contraseña. El código fuente puede alojarse en uno privado con un flujo independiente, pero el ejemplo de este paquete usa un repositorio público. **No subas secretos al repositorio**.
2. Copia el contenido de esta carpeta a la raíz del repositorio. La automatización está en `.github/workflows/publicar-apk.yml`.
3. Recupera la clave **original** de firma Android desde tu ZIP **privado** de Santo Antojo 1.1: `signing/santo-antojo.p12`. Nunca la publiques, la subas al repositorio ni la envíes por chat. Este proyecto no la contiene.
4. En GitHub, entra en **Settings > Secrets and variables > Actions > New repository secret** y crea:
   - `SANTO_KEYSTORE_BASE64`: contenido Base64 de ese archivo `.p12` (no la ruta del archivo).
   - `SANTO_KEYSTORE_PASSWORD`: contraseña del certificado original.
   - `SANTO_KEY_ALIAS`: alias del certificado original.
   - `SANTO_KEY_PASSWORD`: contraseña de la clave original.
5. Abre **Actions > Publicar APK actualizable > Run workflow**. GitHub Actions instalará SDK Android 35 y Gradle 8.7, compilará la APK, la firmará con la clave original y publicará dos recursos en **Releases**: `SantoAntojo.apk` y `update.json`.
6. Instala `SantoAntojo.apk` desde esa publicación inicial (Android puede solicitar permiso de instalación desde el navegador). Si ya tienes Santo Antojo instalada, **no la desinstales**.
7. En la aplicación, abre **Configurar > Actualizaciones** y guarda **una vez** la URL de actualización:

   `https://github.com/USUARIO/REPOSITORIO/releases/latest/download/update.json`

   Sustituye `USUARIO/REPOSITORIO` por los de tu propio repositorio GitHub. A partir de ahí podrás usar **Buscar actualizaciones** desde la app y recibir avisos diarios cuando haya versiones nuevas.

## Para publicar la siguiente versión

1. Actualiza los archivos del proyecto en GitHub y aumenta `versionCode` y `versionName` en `app/build.gradle` (el `versionCode` debe ser mayor que el anterior).
2. Ejecuta **Actions > Publicar APK actualizable > Run workflow**. El APK y `update.json` quedan bajo una nueva versión pública.
3. En tu Android, abre Santo Antojo. La app buscará una actualización después de iniciar sesión como administrador o puedes tocar **Buscar actualizaciones**.
4. Confirma la descarga y la instalación cuando Android la solicite. No necesitas volver a descargar el ZIP.

## Advertencias

- **Este proyecto es código fuente, no una APK ya compilada.** En el entorno de esta conversación no hay Android SDK ni acceso a su repositorio para generar o probar la APK final. Se preparó una compilación automatizada para GitHub, que necesita completar los pasos anteriores. No se ha realizado una instalación real ni validado un dispositivo.
- No subas los ZIP originales a un repositorio público: incluyen secretos o certificados. Este paquete elimina ambos. Evita pegar claves OpenAI, Metricool o Base64 del certificado en ChatGPT.
- El certificado de firma original es necesario para actualizar una app ya instalada. Una firma diferente obligaría a instalar como una app distinta o a desinstalar la anterior, con riesgo de pérdida de datos.
- Al instalar desde fuera de Google Play, Android debe pedir permiso de instalación de origen desconocido. Este mecanismo no concede actualizaciones automáticas silenciosas. Para actualizaciones gestionadas por Play Store sería necesario publicar allí.
- El servicio OpenAI y Metricool del módulo Campañas IA sigue necesitando un servidor HTTPS privado configurado y acceso autorizado; no se habilita al instalar este APK.
- Almacena copias de seguridad del certificado privado original y de los datos exportados en lugares seguros.

## Pruebas rápidas

`node --check app/src/main/assets/app.js`

`node --test tests/update.test.mjs`

`node --test tests/campaign.test.mjs`

`npm install && npm test` (incluye pruebas del POS con jsdom, requiere conexión para instalar dependencias).
