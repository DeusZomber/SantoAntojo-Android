const {JSDOM,VirtualConsole}=require('jsdom');
const assert=require('node:assert/strict'),fs=require('fs'),vm=require('vm');
const source=fs.readFileSync('app/src/main/assets/app.js','utf8');
const css=fs.readFileSync('app/src/main/assets/styles.css','utf8');
const errors=[];const vconsole=new VirtualConsole();vconsole.on('jsdomError',e=>{if(!e.message.includes('navigation'))errors.push(e.message)});
const dom=new JSDOM('<!doctype html><html><head><style>'+css+'</style></head><body><div id="root"></div></body></html>',{url:'https://test.local/',runScripts:'dangerously',virtualConsole:vconsole});
const w=dom.window;w.alert=m=>{};w.confirm=m=>!m.includes('¿Imprimir');w.prompt=()=> '1234';w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=()=>{};
const ctx=dom.getInternalVMContext(),run=s=>vm.runInContext(s,ctx);const doc=w.document;const click=s=>{assert(doc.querySelector(s),'Missing '+s);doc.querySelector(s).click()};const input=(s,v)=>{doc.querySelector(s).value=v};
(async()=>{
run(source);assert(doc.querySelector('.login'));
input('#role','admin');input('#pin','1234');run('login()');
for(const tab of ['venta','inventario','compras','recetas','config','reportes','clientes','gastos','deudas','proveedores','historial']){run(`go('${tab}')`);assert(doc.querySelector('#content h2'),tab)}
run("go('inventario')");input('#iname','Fresas frescas');input('#istock','1000');input('#iunit','g');input('#imin','100');input('#icost','0.10');run('addInventory()');
run("go('recetas');editRecipe('product','f8')");input('[data-ingredient]','100');click('#modal-save');assert(!doc.querySelector('#modal'));assert.equal(run('Object.values(db.recipes.f8)[0]'),100);
run("go('config');assignToppings('p1')");assert(doc.querySelectorAll('.check-row').length>20);const sheet=doc.querySelector('.modal-body');assert.equal(w.getComputedStyle(sheet).overflowY,'auto');run("filterModal('nutella')");assert.equal(doc.querySelectorAll('.filter-row:not([hidden])').length,1);click('#modal-cancel');assert.equal(run("db.phases.find(p=>p.id==='p1').optionIds.length"),2,'cancel retained options');
run('editProduct()');input('#edit-name','Producto prueba');input('#edit-category',"Categoría d'Alan");input('#edit-price','12.50');click('#modal-save');
run("go('venta')");[...doc.querySelectorAll('#sell button')].find(b=>b.textContent==="Categoría d'Alan").click();assert(doc.querySelector('.product').textContent.includes('Producto prueba'));doc.querySelector('.product').click();run('prev()');assert(doc.querySelector('#sell h2').textContent==='Seleccionar producto');
run("start('f8');next()");const list=doc.querySelector('.option-list');list.scrollTop=300;doc.querySelector('.choice').click();assert.equal(doc.querySelector('.option-list').scrollTop,300);assert.equal(w.getComputedStyle(doc.querySelector('.option-list')).overflowY,'auto');
run('phaseIndex=activePhases().length;renderSell();addCart()');assert(doc.querySelector('.cart-link'));run('checkout=true;renderSell()');input('#cash','50');run('pay()');
assert.equal(run('db.sales.length'),1);assert.equal(run('db.inventory[0].stock'),900);assert.equal(run('db.sales[0].change'),10);assert.equal(run('cart.length'),0);
run('window.SantoAndroid={saveText:(name,mime,text)=>window.testExport={name,mime,text},printHtml:html=>window.testPrint=html};exportData()');const exported=w.testExport;assert.equal(JSON.parse(exported.text).sales.length,1);run('exportSalesCSV()');assert(w.testExport.text.includes('Cancelada'));run('printTicket(db.sales[0],false)');assert(w.testPrint.includes('TOTAL $40.00'));
run("start('f8');phaseIndex=activePhases().length;addCart();checkout=true;renderSell();removeCartLine(0)");assert.equal(run('checkout'),false);run('pay()');assert.equal(run('db.sales.length'),1);
run('voidSale(db.sales[0].id);voidSale(db.sales[0].id)');assert.equal(run('db.inventory[0].stock'),1000);assert.equal(run('db.stockMoves.filter(x=>x.kind==="Cancelación").length'),1);
run("db.toppings=db.toppings.filter(x=>x.id!=='cat-nutella');save()");const stored=w.localStorage.getItem('santo_antojo_pos_v4_1');
// Backup validation and preservation before import confirmation.
run("go('config')");const importer=doc.querySelector('input[onchange="importData(this)"]');Object.defineProperty(importer,'files',{value:[new w.File(['{"products":[],"phases":[],"sales":[{}]}'],'bad.json',{type:'application/json'})],configurable:true});run('importData(document.querySelector(\'input[onchange="importData(this)"]\'))');await new Promise(r=>setTimeout(r,40));assert.equal(w.localStorage.getItem('santo_antojo_pos_v4_1'),stored);
Object.defineProperty(importer,'files',{value:[new w.File([exported.text],'backup.json',{type:'application/json'})],configurable:true});run('importData(document.querySelector(\'input[onchange="importData(this)"]\'))');await new Promise(r=>setTimeout(r,40));assert.equal(run('db.sales[0].void||false'),false);assert.equal(run('db.inventory[0].stock'),900);
// Storage failure must keep the cart and avoid a partially recorded sale.
run("go('venta');start('f8');phaseIndex=activePhases().length;addCart();checkout=true;renderSell()");const before=run('db.sales.length');const result=run("(()=>{const old=Storage.prototype.setItem;Storage.prototype.setItem=()=>{throw Error('quota')};let caught=false;try{pay()}catch(e){caught=true}finally{Storage.prototype.setItem=old}return {caught,count:db.sales.length,stock:db.inventory[0].stock,cart:cart.length}})()");assert(result.caught);assert.equal(result.count,before);assert.equal(result.stock,900);assert.equal(result.cart,1);
// Mixed payments cannot create change from card or transfer, and empty cart cannot sell.
run('renderSell()');input('#cash','0');input('#transfer','41');run('pay()');assert.equal(run('db.sales.length'),before);input('#transfer','20');input('#cash','30');run('pay()');assert.equal(run('db.sales.length'),before+1);assert.equal(run('db.sales[0].change'),10);
// Other data-entry operations, purchases and debts.
run("go('compras')");input('#supplier','Proveedor');input('#buyingredient',run('db.inventory[0].id'));input('#buyqty','50');input('#amount','10');run('addPurchase()');assert.equal(run('db.inventory[0].stock'),850);assert.equal(run('db.inventory[0].cost'),.2);
run("go('clientes')");input('#nm','Cliente');input('#ph','123456');run('addClient()');run("go('deudas')");input('#debtor',run('db.clients[0].id'));input('#amt','50');input('#detail','Pedido');run('addDebt()');assert.equal(run('db.debts[0].balance'),50);
run("go('gastos')");input('#nm','Limpieza');input('#amt','25');run('addExpense()');assert.equal(run('db.expenses[0].amount'),25);
run("go('proveedores')");input('#nm','Proveedor');input('#ph','123');input('#notes','Fresas');run('addSupplier()');assert.equal(run('db.suppliers.length'),1);
// Re-opening a database migrates recipes without restoring deleted catalog records.
run("db.toppings=db.toppings.filter(x=>x.id!=='cat-nutella');save()");const persisted=w.localStorage.getItem('santo_antojo_pos_v4_1');const dom2=new JSDOM('<div id="root"></div>',{url:'https://test.local/',runScripts:'outside-only'});dom2.window.localStorage.setItem('santo_antojo_pos_v4_1',persisted);dom2.window.alert=()=>{};vm.runInContext(source,dom2.getInternalVMContext());assert.equal(vm.runInContext("db.toppings.some(x=>x.id==='cat-nutella')",dom2.getInternalVMContext()),false);assert.equal(vm.runInContext('Object.keys(db.recipes.f8).length',dom2.getInternalVMContext()),1);
assert.deepEqual(errors,[]);console.log('PASS: 11 screens rendered; scroll containers; modal search/cancel/save; categories with apostrophes; no-phase back; option scroll preservation; inventory recipes; sales and change; empty sale prevention; cancellations once; purchases; clients; debts; expenses; suppliers; JSON/CSV/native print bridge; invalid backup rejected; valid restore; storage rollback; persistence/migration.');
dom2.window.close();dom.window.close();
})().catch(e=>{console.error(e);dom.window.close();process.exit(1)});
