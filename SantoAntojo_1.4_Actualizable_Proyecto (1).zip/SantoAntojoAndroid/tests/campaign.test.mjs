import assert from 'node:assert/strict';
import {test, after} from 'node:test';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const mediaDir=await mkdtemp(join(tmpdir(),'santo-media-test-'));
process.env.SANTO_CAMPAIGN_TOKEN='1234567890abcdefghijklmnopqrstuv';
process.env.OPENAI_API_KEY='test-only-not-a-real-key';
process.env.METRICOOL_API_TOKEN='mock-metricool-test';
process.env.METRICOOL_USER_ID='123';
process.env.METRICOOL_BLOG_ID='456';
process.env.MEDIA_DIR=mediaDir;
process.env.PUBLIC_ORIGIN='https://campaign.example.com';
const records=[];
const originalFetch=globalThis.fetch;
globalThis.fetch=async (url,options)=>{
  if(String(url).includes('api.openai.com/v1/responses')){
    records.push({operation:'text',payload:JSON.parse(options.body)});
    return new Response(JSON.stringify({output:[{content:[{type:'output_text',text:JSON.stringify({title:'¡Qué antojo!',copy:'Fresas con crema deliciosas',hashtags:'#SantoAntojo'})}]}]}),{status:200});
  }
  if(String(url).includes('api.openai.com/v1/images/edits')){
    records.push({operation:'image'});
    return new Response(JSON.stringify({data:[{b64_json:Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),Buffer.alloc(105)]).toString('base64')}]}),{status:200});
  }
  if(String(url).includes('normalize/image/url')){
    records.push({operation:'normalize',url:String(url)});
    return new Response(JSON.stringify({data:{mediaId:'fake-media-id'}}),{status:200});
  }
  if(String(url).includes('/scheduler/posts')){
    records.push({operation:'schedule',payload:JSON.parse(options.body)});
    return new Response(JSON.stringify({data:{id:'post-123'}}),{status:200});
  }
  throw new Error('Unexpected upstream '+url);
};
const {createCampaignServer}=await import('../server/campaign-server.mjs');
const server=createCampaignServer();
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const base='http://127.0.0.1:'+server.address().port;
after(async()=>{await new Promise(resolve=>server.close(resolve));await rm(mediaDir,{recursive:true,force:true});globalThis.fetch=originalFetch;});
function request(path,body,token=process.env.SANTO_CAMPAIGN_TOKEN){return originalFetch(base+path,{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify(body)});}
const jpeg='data:image/jpeg;base64,'+Buffer.concat([Buffer.from([255,216,255,225]),Buffer.alloc(120,32)]).toString('base64');
let url;
test('no autoriza token incorrecto',async()=>{
  const res=await request('/campaign',{},'incorrecto');assert.equal(res.status,401);
});
test('genera copy estructurado sin enviar credenciales Android',async()=>{
  const res=await request('/campaign',{productName:'Fresas con crema',price:80,goal:'antojo',brief:'Destaca la crema'});
  assert.equal(res.status,200);assert.equal((await res.json()).title,'¡Qué antojo!');
  assert.equal(records.find(x=>x.operation==='text').payload.text.format.type,'json_schema');
});
test('valida peticiones',async()=>{
  const res=await request('/campaign',{productName:100,brief:'x',goal:'antojo'});assert.equal(res.status,400);
});
test('edita foto con endpoint Images',async()=>{
  const res=await request('/image',{image:jpeg,productName:'Fresas',title:'Antojo',brief:'Publicidad natural'});
  assert.equal(res.status,200);assert.ok((await res.json()).image.startsWith('data:image/png;base64,'));
});
test('sube foto pública de manera controlada',async()=>{
  const res=await request('/media',{image:jpeg});assert.equal(res.status,200);url=(await res.json()).url;
  assert.ok(url.startsWith('https://campaign.example.com/media/'));
  const get=await originalFetch(base+new URL(url).pathname);assert.equal(get.status,200);assert.equal(get.headers.get('content-type'),'image/jpeg');
});
test('programa ambas redes solo tras normalizar mediaId',async()=>{
  const when=new Intl.DateTimeFormat('sv-SE',{timeZone:'America/Mexico_City',hourCycle:'h23',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}).format(new Date(Date.now()+20*60000)).replace(' ','T');
  const res=await request('/schedule',{text:'¡Fresas con crema!',when,providers:['facebook','instagram'],imageUrl:url});
  assert.equal(res.status,200);assert.equal((await res.json()).id,'post-123');
  const post=records.find(x=>x.operation==='schedule').payload;
  assert.equal(post.media.mediaId,'fake-media-id');assert.deepEqual(post.providers,[{network:'facebook'},{network:'instagram'}]);
});
test('rechaza URL de imagen ajena',async()=>{
  const when=new Intl.DateTimeFormat('sv-SE',{timeZone:'America/Mexico_City',hourCycle:'h23',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}).format(new Date(Date.now()+20*60000)).replace(' ','T');
  const res=await request('/schedule',{text:'x',when,providers:['instagram'],imageUrl:'https://malicioso.example/media/x.jpg'});assert.equal(res.status,400);
});
