import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const base = new URL('../', import.meta.url);
const read = p => readFileSync(new URL(p,base),'utf8');
test('preserva identificador y eleva versionCode',()=>{
  const g=read('app/build.gradle');
  assert.match(g,/applicationId 'mx\.santoantojo\.pos'/);
  assert.match(g,/versionCode 5/);
  assert.match(g,/versionName '1\.4'/);
  assert.match(g,/SANTO_KEYSTORE_FILE/);
});
test('la instalacion requiere que el usuario autorice Android',()=>{
  const m=read('app/src/main/AndroidManifest.xml');
  const java=read('app/src/main/java/mx/santoantojo/pos/MainActivity.java');
  assert.match(m,/REQUEST_INSTALL_PACKAGES/);
  assert.match(m,/android:exported="false" android:grantUriPermissions="true"/);
  assert.match(java,/canRequestPackageInstalls/);
  assert.match(java,/ACTION_MANAGE_UNKNOWN_APP_SOURCES/);
  assert.match(java,/ACTION_VIEW/);
});
test('la descarga exige HTTPS, SHA256 y paquete correcto',()=>{
  const java=read('app/src/main/java/mx/santoantojo/pos/MainActivity.java');
  assert.match(java,/safeHttps\(downloadUrl\)/);
  assert.match(java,/MessageDigest\.getInstance\("SHA-256"\)/);
  assert.match(java,/getPackageArchiveInfo/);
  assert.match(java,/expectedSha256/);
  assert.match(java,/candidate\.versionCode <= installedVersion\(\)/);
});
test('el POS muestra control de actualización y mantiene su almacenamiento',()=>{
  const js=read('app/src/main/assets/app.js');
  assert.match(js,/function checkForAppUpdate\(/);
  assert.match(js,/function santoUpdateResult\(/);
  assert.match(js,/Actualiza Santo Antojo/);
  assert.match(js,/function persistDatabase\(/);
});
test('el flujo automatizado compila firmado sin publicar credenciales',()=>{
  const yaml=read('.github/workflows/publicar-apk.yml');
  assert.match(yaml,/secrets\.SANTO_KEYSTORE_BASE64/);
  assert.match(yaml,/assembleRelease/);
  assert.match(yaml,/softprops\/action-gh-release@v2/);
});
