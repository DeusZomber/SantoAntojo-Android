"""Create public, integrity-checked update metadata for a signed Santo Antojo APK."""
import hashlib
import json
import os
import re
from pathlib import Path

root=Path(__file__).resolve().parents[2]
gradle=(root/'app/build.gradle').read_text()
code=int(re.search(r'\bversionCode\s+(\d+)',gradle).group(1))
version=re.search(r'\bversionName\s+[\'\"]([^\'\"]+)[\'\"]',gradle).group(1)
apk=root/'app/build/outputs/apk/release/app-release.apk'
if not apk.exists() or apk.stat().st_size<10_000:
    raise SystemExit('No se encontró una APK release firmada.')
release=root/'release'
release.mkdir(exist_ok=True)
out=release/'SantoAntojo.apk'
out.write_bytes(apk.read_bytes())
sha=hashlib.sha256(out.read_bytes()).hexdigest()
repo=os.environ.get('GITHUB_REPOSITORY','').strip()
if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',repo):
    raise SystemExit('Falta GITHUB_REPOSITORY (usuario/repositorio).')
tag=f'v{version}'
feed={'versionCode':code,'versionName':version,
      'apkUrl':f'https://github.com/{repo}/releases/download/{tag}/SantoAntojo.apk',
      'sha256':sha}
(release/'update.json').write_text(json.dumps(feed,indent=2,ensure_ascii=False)+'\n')
print(f'Generada publicación {tag}, versionCode={code}, sha256={sha}')
with open(os.environ['GITHUB_OUTPUT'],'a') as f:
    f.write(f'tag={tag}\nversion={version}\n')
