SANTO ANTOJO 1.4 — VERSION ACTUALIZABLE

Abre EMPIEZA_AQUI.md para configurar una sola instalacion inicial y posteriores actualizaciones desde la app.

SANTO ANTOJO 1.3 — NUEVO MODULO CAMPANAS CON IA
- El proyecto incluye un puente HTTPS nativo para generar copys e imagenes con un servidor privado.
- Se agregan revisiones, edicion de textos, guardado local de borradores y programacion condicional en Metricool.
- NO trae claves API ni archivos privados de firma. NO ES APK; es proyecto Android.
- Lee CAMPAIGN_SETUP.md para despliegue, configuracion y limitaciones.
- Las nuevas funciones de campañas requieren internet, OpenAI API y servidor propio.
- Metricool solo permite la API a clientes de planes Advanced o Custom.
- La publicacion depende de que las cuentas acepten los tipos de media y permisos.

SANTO ANTOJO · ANDROID 1.3

INSTALACIÓN
Abre SantoAntojo.apk en tu celular Android 8 o superior. Instala como actualización
sobre la versión anterior: conserva el mismo identificador y certificado de firma.
No desinstales la app ni borres sus datos, pues las ventas se guardan localmente.

USO
- No requiere internet para vender, configurar productos ni controlar existencias.
- Desliza el menú de arriba hacia los lados para acceder a todas las secciones.
- Desliza las listas verticalmente; las tablas también admiten movimiento horizontal.
- “Ver pedido” permanece accesible abajo al agregar productos.
- Configurar > fases > elegir opciones: busca y marca casillas; pulsa Guardar.
- Recetas: configura cantidades por insumo en cada producto y topping.
- Configurar > Respaldo: exporta un JSON y elige dónde guardarlo con Android.
- Reportes: exporta ventas CSV con el mismo selector.
- La impresión usa el servicio de impresión de Android (incluido Guardar como PDF
  si está disponible). No incorpora un controlador Bluetooth ESC/POS específico.
- Las fotos se reducen antes de guardarlas para ocupar menos espacio.

CAMBIOS
Se inicializan recetas, recetas de extras y movimientos de inventario.
Se comprueban respaldos antes de reemplazar datos.
Se evita registrar ventas vacías y dar cambio sobre tarjeta o transferencia.
Si falla el almacenamiento, se revierte el cambio en memoria y se conserva el
pedido para volver a intentar cobrar; se muestra una advertencia.
Cancelar una venta devuelve el consumo de ingredientes una sola vez.
Los toppings y fases eliminados ya no se recrean al reiniciar.
Las categorías con apóstrofos funcionan correctamente.
Los avisos Android muestran “Santo Antojo” en lugar de la dirección file://.
Se incluyen selector de archivos, exportación y servicio de impresión nativos.

ARCHIVOS
app/src/main/assets/index.html : pantalla inicial
app/src/main/assets/styles.css : estilos y adaptación a celulares
app/src/main/assets/app.js : lógica de ventas, configuración y almacenamiento
app/src/main/assets/fotos : fotografías offline
app/src/main/java/mx/santoantojo/pos/MainActivity.java : integración con Android

COMPILAR
Abre esta carpeta como proyecto en Android Studio. Sincroniza Gradle y usa
Build > Generate App Bundles or APKs > Generate APKs, o assembleRelease.
Usa JDK 17, Android SDK 35 y Android Gradle Plugin 8.6.1 (Gradle 8.7).
La primera instalación de herramientas y la sincronización requieren internet;
la aplicación terminada funciona sin conexión.

FIRMA PARA ACTUALIZACIONES
El certificado de firma anterior se excluyó de esta entrega por seguridad.
Conserva este proyecto en privado y no publiques ni compartas esa clave.
Su configuración de compilación está en app/build.gradle. Cambiar de clave
impide actualizar la instalación existente con una APK nueva.

PRUEBAS
Desde esta carpeta: npm install, seguido de npm test.
Las pruebas usan un DOM simulado: once pantallas, formularios, selección de
opciones, recetas, ventas, cambio, cancelaciones, compras, clientes, deudas,
gastos, proveedores, validación/restauración de respaldos y fallo de guardado.
La compilación nativa, la integridad de assets y la firma APK se verificaron.
No se ejecutó la app en un emulador ni teléfono Android. El desplazamiento
real, los permisos/selectores de Android y la impresión requieren prueba en
tu dispositivo. Las pruebas de DOM no comprueban la distribución visual real.

DATOS
La clave de almacenamiento y la dirección local se conservan para mantener los
datos al actualizar. Los respaldos y los datos se guardan por dispositivo; no
hay sincronización entre celulares. Los PIN locales no equivalen a cuentas
con autenticación de servidor. PIN inicial: admin 1234, confianza 2468.

ACTUALIZACIÓN 1.2: Consulta CAMPAIGN_SETUP.md para las campañas. El archivo
privado de firma y cualquier texto con API key fueron excluidos del paquete de
entrega. La sección de campañas guarda borradores y permite generar copys sólo
cuando se configure un backend HTTPS. Publicación automática no implementada.
