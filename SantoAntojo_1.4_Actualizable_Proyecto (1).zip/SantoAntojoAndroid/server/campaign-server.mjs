/**
 * Santo Antojo 1.3 - backend privado, Node.js 20+ sin dependencias.
 * Ejecutar detrás de proxy HTTPS y configurar un directorio MEDIA_DIR persistente.
 * NUNCA guardar claves OpenAI/Metricool en la app Android.
 */
import http from 'node:http';
import {randomUUID,timingSafeEqual} from 'node:crypto';
import {promises as fs} from 'node:fs';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';

const PORT=Number(process.env.PORT||8787);
const HOST=process.env.HOST||'127.0.0.1';
const ACCESS=process.env.SANTO_CAMPAIGN_TOKEN||'';
const OPENAI=process.env.OPENAI_API_KEY||'';
const PUBLIC=process.env.PUBLIC_ORIGIN||'';
const MEDIA_DIR=process.env.MEDIA_DIR||join(process.cwd(),'private-campaign-media');
const MC=process.env.METRICOOL_API_TOKEN||'';
const MC_USER=process.env.METRICOOL_USER_ID||'';
const MC_BRAND=process.env.METRICOOL_BLOG_ID||'';
const MODEL=process.env.OPENAI_TEXT_MODEL||'gpt-4.1-mini';
const IMAGE_MODEL=process.env.OPENAI_IMAGE_MODEL||'gpt-image-2.5-flare';
const UPSTREAM_OPENAI=process.env.OPENAI_API_ORIGIN||'https://api.openai.com';
const UPSTREAM_MC=process.env.METRICOOL_API_ORIGIN||'https://app.metricool.com';
// Las URLs de upstream configurables se usan únicamente para pruebas automatizadas; en producción mantenlas predeterminadas.
const schema={type:'object',properties:{title:{type:'string'},copy:{type:'string'},hashtags:{type:'string'}},required:['title','copy','hashtags'],additionalProperties:false};
const limits=new Map();

function json(res,code,data){res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(data));}
function bearerOK(req){
  const actual=req.headers.authorization||'';
  const expected='Bearer '+ACCESS;
  if(!ACCESS || ACCESS.length<24 || actual.length!==expected.length)return false;
  return timingSafeEqual(Buffer.from(actual),Buffer.from(expected));
}
function quota(kind,max=80){
  const now=Date.now(),entry=limits.get(kind)||{count:0,start:now};
  if(now-entry.start>86400000){entry.start=now;entry.count=0;}
  entry.count++;limits.set(kind,entry);return entry.count<=max;
}
async function readJson(req,maxBytes=7000000){
  const chunks=[];let size=0;
  for await(const chunk of req){size+=chunk.length;if(size>maxBytes)throw Object.assign(Error('Solicitud demasiado grande'),{status:413});chunks.push(chunk);}
  try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}
  catch{throw Object.assign(Error('JSON inválido'),{status:400});}
}
function str(x,max=160){return typeof x==='string' && x.length<=max;}
function validation(b){if(!b||!str(b.productName)||!b.productName.trim()||!str(b.goal,30)||!str(b.brief,2000))throw Object.assign(Error('Producto u objetivo inválido'),{status:400});}
async function upstreamJson(url,options,timeout=90000){
  const resp=await fetch(url,{...options,redirect:'error',signal:AbortSignal.timeout(timeout)});
  const raw=await resp.text();let data;try{data=JSON.parse(raw);}catch{data={};}
  if(!resp.ok)throw Object.assign(Error('Servicio externo no disponible ('+resp.status+')'),{status:502});
  return data;
}
function getImage(dataUrl){
  if(typeof dataUrl!=='string'||dataUrl.length>6800000)throw Object.assign(Error('Imagen muy grande'),{status:413});
  const match=/^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/.exec(dataUrl);
  if(!match)throw Object.assign(Error('Elige JPG, PNG o WebP'),{status:400});
  const b=Buffer.from(match[2],'base64');
  const mime=match[1];
  const isJpg=b.length>4&&b[0]===255&&b[1]===216&&b[2]===255;
  const isPng=b.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
  const isWebp=b.length>12&&b.toString('ascii',0,4)==='RIFF'&&b.toString('ascii',8,12)==='WEBP';
  if(b.length<100||b.length>5000000||!(mime==='jpeg'&&isJpg||mime==='png'&&isPng||mime==='webp'&&isWebp))throw Object.assign(Error('Archivo de imagen inválido'),{status:400});
  return {bytes:b,ext:mime==='jpeg'?'jpg':mime,mime:'image/'+mime};
}
async function generateText(b){
  validation(b);
  if(!OPENAI)throw Object.assign(Error('OpenAI no está configurado en el servidor'),{status:503});
  const request={model:MODEL,input:[
    {role:'developer',content:'Redacta campañas auténticas para Santo Antojo, postres y bebidas en Michoacán. Usa español mexicano amable y profesional. Responde solo JSON estructurado. No inventes precios, promociones, ingredientes, descuentos, ubicación de entrega ni premios. No afirmes características que el cliente no haya especificado. Evita exageraciones y spam.'},
    {role:'user',content:JSON.stringify({producto:b.productName,precio:b.price,objetivo:b.goal,indicaciones:b.brief})}
  ],text:{format:{type:'json_schema',name:'anuncio_santo_antojo',strict:true,schema}},max_output_tokens:500};
  const data=await upstreamJson(UPSTREAM_OPENAI+'/v1/responses',{method:'POST',headers:{Authorization:'Bearer '+OPENAI,'Content-Type':'application/json'},body:JSON.stringify(request)});
  const output=data.output?.flatMap(x=>x.content||[]).find(x=>x.type==='output_text')?.text;
  if(!output)throw Error('Respuesta de texto vacía');
  const result=JSON.parse(output);
  if(!str(result.title,160)||!str(result.copy,1500)||!str(result.hashtags,300))throw Error('Texto inesperado de OpenAI');
  return result;
}
async function generateImage(b){
  if(!OPENAI)throw Object.assign(Error('OpenAI no está configurado en el servidor'),{status:503});
  if(!str(b.productName)||!str(b.brief,2000)||!str(b.title,160))throw Object.assign(Error('Datos de anuncio inválidos'),{status:400});
  const im=getImage(b.image);
  const form=new FormData();
  form.append('model',IMAGE_MODEL);
  form.append('image',new Blob([im.bytes],{type:im.mime}), 'producto.'+im.ext);
  form.append('size','1024x1536');
  form.append('quality','medium');
  form.append('prompt',`Fotografía publicitaria vertical atractiva y realista para Santo Antojo (México). Usa el producto original como referencia principal. NO inventes ingredientes, precios, etiquetas o logotipos. Preserva lo mejor posible la forma, color, producto y envase. Fondo profesional e iluminación cálida de antojo. No añadas texto legible. Producto: ${b.productName}. Enfoque: ${b.title}. Contexto: ${b.brief}.`);
  const data=await upstreamJson(UPSTREAM_OPENAI+'/v1/images/edits',{method:'POST',headers:{Authorization:'Bearer '+OPENAI},body:form},115000);
  const base64=data.data?.[0]?.b64_json;
  if(typeof base64!=='string'||base64.length>11500000)throw Error('Respuesta gráfica no disponible');
  const fmt=data.output_format;
  const mime=fmt==='jpeg'?'jpeg':fmt==='webp'?'webp':'png';
  return {image:'data:image/'+mime+';base64,'+base64};
}
async function uploadMedia(b){
  if(!PUBLIC||!/^https:\/\/[a-z0-9.-]+(?::443)?$/i.test(PUBLIC))throw Object.assign(Error('Configura PUBLIC_ORIGIN (HTTPS) en el servidor'),{status:503});
  const im=getImage(b.image);await fs.mkdir(MEDIA_DIR,{recursive:true,mode:0o700});
  const file=randomUUID()+'.'+im.ext;
  await fs.writeFile(join(MEDIA_DIR,file),im.bytes,{flag:'wx',mode:0o600});
  return {url:PUBLIC+'/media/'+file};
}
async function sendToMetricool(b){
  if(!MC || !MC_USER || !MC_BRAND)throw Object.assign(Error('Metricool API no está configurada (requiere plan Advanced o Custom)'),{status:503});
  if(!str(b.text,2500)||!b.text.trim()||!/^\d{4}-\d\d-\d\dT\d\d:\d\d$/.test(b.when||''))throw Object.assign(Error('Texto u horario inválido'),{status:400});
  const date=Date.parse(b.when+':00-06:00'); // zona centro de México sin cambio de horario
  if(!Number.isFinite(date)||date<Date.now()+90000||date>Date.now()+365*86400000)throw Object.assign(Error('Usa fecha futura válida dentro de un año'),{status:400});
  const networks=b.providers;
  if(!Array.isArray(networks)||networks.length<1||networks.length>2||new Set(networks).size!==networks.length||networks.some(x=>!['facebook','instagram'].includes(x)))throw Object.assign(Error('Selecciona Instagram y/o Facebook'),{status:400});
  if(!PUBLIC || !str(b.imageUrl,500) || !/^https:\/\/[a-z0-9.-]+(?::443)?$/i.test(PUBLIC) || !b.imageUrl.startsWith(PUBLIC+'/media/') || !/^https:\/\/[a-z0-9.-]+(?:\:443)?\/media\/[a-f0-9-]{36}\.(jpg|png|webp)$/i.test(b.imageUrl))throw Object.assign(Error('Antes de programar, sube la foto a este servidor'),{status:400});
  const filename=b.imageUrl.slice((PUBLIC+'/media/').length);
  // El archivo debe pertenecer a nuestro servidor: nunca pasamos URLs arbitrarias a normalize.
  await fs.access(join(MEDIA_DIR,filename));
  const params=new URLSearchParams({userId:MC_USER,blogId:MC_BRAND});
  const headers={'X-Mc-Auth':MC};
  const normalized=await upstreamJson(UPSTREAM_MC+'/api/actions/normalize/image/url?'+new URLSearchParams({url:b.imageUrl,userId:MC_USER,blogId:MC_BRAND}),{headers},30000);
  const mediaId=normalized?.data?.mediaId ?? normalized?.data?.id ?? normalized?.mediaId ?? normalized?.id ?? normalized?.data?.media?.mediaId;
  if(typeof mediaId!=='string' && typeof mediaId!=='number')throw Object.assign(Error('Metricool no devolvió mediaId; no se programó una publicación sin imagen'),{status:502});
  const post={publicationDate:{dateTime:b.when+':00',timezone:'America/Mexico_City'},text:b.text,providers:networks.map(network=>({network})),media:{mediaId},autoPublish:true};
  const response=await upstreamJson(UPSTREAM_MC+'/api/v2/scheduler/posts?'+params,{method:'POST',headers:{...headers,'Content-Type':'application/json'},body:JSON.stringify(post)},40000);
  return {id:response?.data?.id || response?.id || '',status:'scheduled',providers:networks};
}
async function handler(req,res){
  const path=new URL(req.url||'/', 'http://localhost').pathname;
  if(req.method==='GET'&&/^\/media\/[0-9a-f-]{36}\.(jpg|png|webp)$/.test(path)){
    const name=path.slice(7);try {
      const bytes=await fs.readFile(join(MEDIA_DIR,name));
      const ext=name.split('.').pop();
      res.writeHead(200,{'Content-Type':ext==='jpg'?'image/jpeg':'image/'+ext,'Cache-Control':'public,max-age=31536000,immutable','X-Content-Type-Options':'nosniff'});res.end(bytes);
    }catch{json(res,404,{error:'Imagen no encontrada'});}return;
  }
  if(req.method==='GET'&&path==='/health'){json(res,200,{service:'santo-antojo-campaigns',version:'1.3',openai:!!OPENAI,metricool:!!MC,mediaConfigured:!!PUBLIC});return;}
  if(req.method!=='POST'||!['/campaign','/image','/media','/schedule'].includes(path)){json(res,404,{error:'Ruta no encontrada'});return;}
  if(!bearerOK(req)){json(res,401,{error:'Código de acceso no válido'});return;}
  if(!quota(path,path==='/image'?20:path==='/schedule'?30:100)){json(res,429,{error:'Límite diario alcanzado'});return;}
  try{
    const b=await readJson(req);
    const result=path==='/campaign'?await generateText(b):path==='/image'?await generateImage(b):path==='/media'?await uploadMedia(b):await sendToMetricool(b);
    json(res,200,result);
  }catch(error){
    const code=error?.status||500;
    // Nunca devolver datos privados ni la respuesta completa del proveedor.
    json(res,code,{error:code===500?'No se completó la operación en el servidor':String(error.message||'Error')});
  }
}
export function createCampaignServer(){return http.createServer((req,res)=>{handler(req,res).catch(()=>json(res,500,{error:'Error del servidor'}));});}
if(process.argv[1] && fileURLToPath(import.meta.url)===process.argv[1]){
  if(ACCESS.length<24 || /^sk-/.test(ACCESS))throw Error('Configura SANTO_CAMPAIGN_TOKEN aleatorio (mínimo 24 caracteres), distinto de la clave API OpenAI.');
  createCampaignServer().listen(PORT,HOST,()=>console.log('Santo Antojo 1.3 escuchando en '+HOST+':'+PORT+'; usa proxy HTTPS público.'));
}
