// Compatibility for WebViews that predate structuredClone.
if (!window.structuredClone)
  window.structuredClone = (value) => JSON.parse(JSON.stringify(value));
const record = (value) =>
  value && typeof value === "object" && !Array.isArray(value);
const idOK = (value) =>
  typeof value === "string" &&
  /^[A-Za-z0-9_-]{1,100}$/.test(value) &&
  !["__proto__", "constructor", "prototype"].includes(value);
function normalizeDatabase(value) {
  if (!record(value)) throw Error("El respaldo no contiene una base de datos.");
  const data = structuredClone(value);
  for (const key of ["products", "phases", "sales"])
    if (!Array.isArray(data[key]))
      throw Error("Falta la lista de " + key + ".");
  for (const key of [
    "inventory",
    "purchases",
    "users",
    "audit",
    "toppings",
    "clients",
    "expenses",
    "debts",
    "suppliers",
    "stockMoves",
  ]) {
    if (data[key] == null) data[key] = [];
    if (!Array.isArray(data[key])) throw Error("Lista inválida: " + key);
  }
  for (const key of [
    "products",
    "phases",
    "sales",
    "inventory",
    "purchases",
    "toppings",
    "clients",
    "expenses",
    "debts",
    "suppliers",
    "stockMoves",
  ]) {
    const ids = new Set();
    for (const item of data[key]) {
      if (!record(item) || !idOK(item.id) || ids.has(item.id))
        throw Error("Registro inválido o repetido en " + key + ".");
      ids.add(item.id);
    }
  }
  for (const key of ["recipes", "optionRecipes"]) {
    if (data[key] == null) data[key] = {};
    if (!record(data[key])) throw Error("Recetas inválidas.");
    for (const [id, values] of Object.entries(data[key])) {
      if (!idOK(id) || !record(values)) throw Error("Receta inválida.");
      for (const [ingredient, amount] of Object.entries(values)) {
        if (
          !idOK(ingredient) ||
          typeof amount !== "number" ||
          !Number.isFinite(amount) ||
          amount < 0
        )
          throw Error("Cantidad de receta inválida.");
      }
    }
  }
  for (const item of [...data.products, ...data.toppings]) {
    if (
      typeof item.name !== "string" ||
      !item.name.trim() ||
      !Number.isFinite(item.price) ||
      item.price < 0
    )
      throw Error("Nombre o precio inválido.");
    if (
      item.photo &&
      !/^(fotos\/[a-zA-Z0-9_-]+\.webp|data:image\/(jpeg|png|webp|gif);base64,[A-Za-z0-9+/=\s]+)$/.test(
        item.photo,
      )
    )
      item.photo = "";
  }
  for (const p of data.products)
    if (typeof p.category !== "string") p.category = "Otros";
  for (const p of data.phases) {
    if (typeof p.name !== "string") throw Error("Fase sin nombre.");
    for (const key of ["productIds", "optionIds"])
      if (
        p[key] != null &&
        (!Array.isArray(p[key]) || p[key].some((id) => !idOK(id)))
      )
        throw Error("Opciones de fase inválidas.");
    if (
      p.options != null &&
      (!Array.isArray(p.options) ||
        p.options.some(
          (o) =>
            !record(o) ||
            !idOK(o.id) ||
            typeof o.name !== "string" ||
            !Number.isFinite(o.price) ||
            o.price < 0,
        ))
    )
      throw Error("Opciones antiguas inválidas.");
    if (
      p.priceOverrides != null &&
      (!record(p.priceOverrides) ||
        Object.entries(p.priceOverrides).some(
          ([id, v]) => !idOK(id) || !Number.isFinite(v) || v < 0,
        ))
    )
      throw Error("Precio de fase inválido.");
  }
  for (const item of data.inventory) {
    if (
      typeof item.name !== "string" ||
      typeof item.unit !== "string" ||
      !Number.isFinite(item.stock)
    )
      throw Error("Insumo inválido.");
    item.min ??= 0;
    item.cost ??= 0;
    if (![item.min, item.cost].every((n) => Number.isFinite(n) && n >= 0))
      throw Error("Costo o mínimo inválido.");
  }
  for (const sale of data.sales) {
    if (
      !Array.isArray(sale.items) ||
      !Number.isFinite(sale.total) ||
      sale.total < 0 ||
      !Number.isFinite(Date.parse(sale.at))
    )
      throw Error("Venta inválida.");
    for (const item of sale.items)
      if (
        !record(item) ||
        typeof item.name !== "string" ||
        !Number.isFinite(item.price) ||
        !Array.isArray(item.description)
      )
        throw Error("Detalle de venta inválido.");
  }
  data.pin = String(data.pin || "1234");
  data.trustedPin = String(data.trustedPin || "2468");
  if (!/^\d{4,8}$/.test(data.pin) || !/^\d{4,8}$/.test(data.trustedPin))
    throw Error("PIN inválido.");
  return data;
}
function loadDatabase() {
  try {
    const raw = localStorage.getItem(KEY) || localStorage.getItem(OLD_KEY);
    return normalizeDatabase(raw ? JSON.parse(raw) : seed);
  } catch (error) {
    document.querySelector("#root").innerHTML =
      '<main class="login panel"><h2>No se pudo abrir tu información</h2><p>Los datos guardados no se han borrado. Cierra y vuelve a abrir la aplicación. Conserva tu respaldo y comparte este mensaje si el problema continúa.</p><p id="load-detail"></p></main>';
    document.querySelector("#load-detail").textContent = error.message;
    throw error;
  }
}
let lastSaved = null;
function persistDatabase() {
  try {
    const raw = JSON.stringify(db);
    localStorage.setItem(KEY, raw);
    lastSaved = raw;
    return true;
  } catch (error) {
    if (lastSaved) db = JSON.parse(lastSaved);
    alert(
      "No se guardó el cambio. El almacenamiento está lleno o no está disponible. Exporta un respaldo y reduce el tamaño de las fotos antes de volver a intentarlo.",
    );
    throw Error("No se pudo guardar el cambio.");
  }
}
function scrollToSale() {
  document
    .querySelector("#sell")
    ?.scrollIntoView({ block: "start", behavior: "smooth" });
}
function toast(message) {
  let box = document.querySelector("#toast");
  if (!box) {
    box = document.createElement("div");
    box.id = "toast";
    box.setAttribute("role", "status");
    document.body.append(box);
  }
  box.textContent = message;
  box.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => box.classList.remove("show"), 2600);
}
let modalReturnFocus = null;
function openModal(title, body, onSave, label = "Guardar") {
  closeModal();
  modalReturnFocus = document.activeElement;
  const overlay = document.createElement("div");
  overlay.id = "modal";
  overlay.className = "modal-backdrop";
  overlay.innerHTML = `<section class="modal-sheet" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-head"><h2 id="modal-title">${esc(title)}</h2><button type="button" aria-label="Cerrar" id="modal-close">✕</button></div><div class="modal-body">${body}</div><div class="modal-actions"><button id="modal-cancel">Cancelar</button><button id="modal-save" class="primary">${esc(label)}</button></div></section>`;
  document.body.append(overlay);
  document.body.classList.add("modal-open");
  $("#modal-close").onclick = $("#modal-cancel").onclick = closeModal;
  $("#modal-save").onclick = () => {
    if (onSave() !== false) closeModal();
  };
  overlay.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      closeModal();
    }
    if (e.key === "Tab") {
      const list = [
        ...overlay.querySelectorAll("button,input,select,textarea"),
      ].filter((x) => !x.disabled && !x.hidden);
      const a = list[0],
        b = list[list.length - 1];
      if (e.shiftKey && document.activeElement === a) {
        e.preventDefault();
        b.focus();
      } else if (!e.shiftKey && document.activeElement === b) {
        e.preventDefault();
        a.focus();
      }
    }
  });
  $("#modal-close").focus({ preventScroll: true });
}
function closeModal() {
  const old = document.querySelector("#modal");
  if (old) {
    old.remove();
    document.body.classList.remove("modal-open");
    if (modalReturnFocus?.isConnected)
      modalReturnFocus.focus({ preventScroll: true });
  }
}
function filterModal(query) {
  const q = query.toLocaleLowerCase("es");
  document
    .querySelectorAll("#modal .filter-row")
    .forEach((row) => (row.hidden = !row.dataset.search.includes(q)));
}
function handleBack() {
  if ($("#modal")) {
    closeModal();
    return true;
  }
  if (checkout) {
    checkout = false;
    renderSell();
    return true;
  }
  if (current) {
    prev();
    return true;
  }
  if (tab !== "venta") {
    go("venta");
    return true;
  }
  if (cart.length) {
    alert("Tienes un pedido sin cobrar. Cóbralo o vacíalo antes de salir.");
    return true;
  }
  return false;
}
function saveTextFile(name, type, text) {
  if (window.SantoAndroid?.saveText) {
    SantoAndroid.saveText(name, type, text);
    return;
  }
  const url = URL.createObjectURL(
    new Blob([text], { type: type + ";charset=utf-8" }),
  );
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}
function removeCartLine(index) {
  cart.splice(index, 1);
  if (!cart.length) checkout = false;
  renderCart();
  renderSell();
}
function emptyCart() {
  if (confirm("¿Vaciar pedido?")) {
    cart = [];
    checkout = false;
    renderCart();
    renderSell();
  }
}
function selectCategory(index) {
  category = [...new Set(db.products.map((p) => p.category))][index];
  renderSell();
}
function presentError(event) {
  console.error(event.error || event.reason || event.message);
  if (document.querySelector("#content"))
    toast("No se completó la acción. Revisa los datos e inténtalo otra vez.");
}
window.addEventListener("error", presentError);
window.addEventListener("unhandledrejection", presentError);
function cartTotal() {
  return (
    Math.round(cart.reduce((sum, item) => sum + Number(item.price), 0) * 100) /
    100
  );
}

const KEY = "santo_antojo_pos_v4_1";
const OLD_KEY = "santo_antojo_pos_v4";
const seed = {
  pin: "1234",
  trustedPin: "2468",
  logo: "",
  products: [
    {
      id: "f8",
      name: "Fresas 8 oz",
      price: 40,
      category: "Fresas",
      photo: "fotos/fresas-8oz.webp",
    },
    {
      id: "f16",
      name: "Fresas 16 oz",
      price: 65,
      category: "Fresas",
      photo: "fotos/fresas-16oz.webp",
    },
    {
      id: "f32",
      name: "Fresas 32 oz",
      price: 115,
      category: "Fresas",
      photo: "fotos/fresas-32oz.webp",
    },
    {
      id: "c1",
      name: "Crepa",
      price: 45,
      category: "Crepas",
      photo: "fotos/crepa.webp",
    },
  ],
  phases: [
    {
      id: "p1",
      name: "Preparación",
      multi: false,
      required: false,
      options: [
        { id: "o1", name: "Crema", price: 0, photo: "" },
        { id: "o2", name: "Chantilly", price: 0, photo: "" },
      ],
      categories: ["Fresas"],
    },
    {
      id: "p2",
      name: "Toppings",
      multi: true,
      required: false,
      options: [],
      categories: ["Fresas", "Crepas"],
    },
    {
      id: "p3",
      name: "Complementos",
      multi: true,
      required: false,
      options: [],
      categories: ["Fresas", "Crepas"],
    },
    {
      id: "p4",
      name: "Extras",
      multi: true,
      required: false,
      extras: true,
      options: [],
      categories: ["Fresas", "Crepas"],
    },
  ],
  inventory: [],
  purchases: [],
  sales: [],
  users: [],
  audit: [],
};
const isNewDatabase =
  !localStorage.getItem(KEY) && !localStorage.getItem(OLD_KEY);
let db = loadDatabase(); // Migración: cada fase se asigna a productos concretos y las opciones se guardan una sola vez.
const defaultProductPhotos = {
  f8: "fotos/fresas-8oz.webp",
  f16: "fotos/fresas-16oz.webp",
  f32: "fotos/fresas-32oz.webp",
  c1: "fotos/crepa.webp",
};
for (const p of db.products) {
  if (defaultProductPhotos[p.id] && !p.photo)
    p.photo = defaultProductPhotos[p.id];
}
db.toppings ??= [];
for (const p of db.phases) {
  if (!Array.isArray(p.productIds))
    p.productIds = db.products
      .filter((x) => (p.categories || []).includes(x.category))
      .map((x) => x.id);
  p.optionIds ??= [];
  for (const o of p.options || []) {
    let shared = db.toppings.find((x) => x.id === o.id);
    if (!shared) {
      shared = { ...o };
      db.toppings.push(shared);
    }
    if (!p.optionIds.includes(shared.id)) p.optionIds.push(shared.id);
  }
  delete p.options;
}

const catalogV3 = [
  {
    id: "cat-chocoretas",
    name: "Chocoretas",
    price: 5,
    group: "normal",
    photo: "fotos/chocoretas.webp",
  },
  {
    id: "cat-chispas-de-chocolate",
    name: "Chispas de chocolate",
    price: 5,
    group: "normal",
    photo: "fotos/chispas-de-chocolate.webp",
  },
  {
    id: "cat-chispas-de-chocolate-naranjas",
    name: "Chispas de chocolate (naranjas)",
    price: 5,
    group: "normal",
    photo: "fotos/chispas-de-chocolate-naranjas.webp",
  },
  {
    id: "cat-almendra",
    name: "Almendra",
    price: 5,
    group: "normal",
    photo: "fotos/almendra.webp",
  },
  {
    id: "cat-almendra-fileteada",
    name: "Almendra fileteada",
    price: 5,
    group: "normal",
    photo: "fotos/almendra-fileteada.webp",
  },
  {
    id: "cat-nuez",
    name: "Nuez",
    price: 5,
    group: "normal",
    photo: "fotos/nuez.webp",
  },
  {
    id: "cat-granola",
    name: "Granola",
    price: 5,
    group: "normal",
    photo: "fotos/granola.webp",
  },
  {
    id: "cat-galleta-oreo",
    name: "Galleta Oreo",
    price: 5,
    group: "normal",
    photo: "fotos/galleta-oreo.webp",
  },
  {
    id: "cat-chococrispis",
    name: "Chococrispis",
    price: 5,
    group: "normal",
    photo: "fotos/chococrispis.webp",
  },
  {
    id: "cat-chocolate-blanco",
    name: "Chocolate blanco",
    price: 5,
    group: "normal",
    photo: "fotos/chocolate-blanco.webp",
  },
  {
    id: "cat-chocolate-relleno",
    name: "Chocolate relleno",
    price: 5,
    group: "normal",
    photo: "fotos/chocolate-relleno.webp",
  },
  {
    id: "cat-semillas-de-calabaza",
    name: "Semillas de calabaza",
    price: 5,
    group: "normal",
    photo: "fotos/semillas-de-calabaza.webp",
  },
  {
    id: "cat-chocolate-liquido",
    name: "Chocolate líquido",
    price: 5,
    group: "normal",
    photo: "fotos/chocolate-liquido.webp",
  },
  {
    id: "cat-chocolate-ferrero",
    name: "Chocolate Ferrero",
    price: 15,
    group: "premium",
    photo: "fotos/chocolate-ferrero.webp",
  },
  {
    id: "cat-chocolate-raffaello",
    name: "Chocolate Raffaello",
    price: 15,
    group: "premium",
    photo: "fotos/chocolate-raffaello.webp",
  },
  {
    id: "cat-kinder-delice",
    name: "Kinder Delice",
    price: 20,
    group: "premium",
    photo: "fotos/kinder-delice.webp",
  },
  {
    id: "cat-kinder-bueno",
    name: "Kinder Bueno",
    price: 30,
    group: "premium",
    photo: "fotos/kinder-bueno.webp",
  },
  {
    id: "cat-kinder-sorpresa",
    name: "Kinder Sorpresa",
    price: 30,
    group: "premium",
    photo: "fotos/kinder-sorpresa.webp",
  },
  {
    id: "cat-kinder-max",
    name: "Kinder Max",
    price: 20,
    group: "premium",
    photo: "fotos/kinder-max.webp",
  },
  {
    id: "cat-kinder",
    name: "Kinder",
    price: 10,
    group: "premium",
    photo: "fotos/kinder-max.webp",
  },
  {
    id: "cat-nutella",
    name: "Nutella",
    price: 10,
    group: "premium",
    photo: "fotos/nutella.webp",
  },
  {
    id: "cat-manzana",
    name: "Manzana",
    price: 5,
    group: "fruta",
    photo: "fotos/manzana.webp",
  },
  {
    id: "cat-zarzamora",
    name: "Zarzamora",
    price: 5,
    group: "fruta",
    photo: "fotos/zarzamora.webp",
  },
  {
    id: "cat-platano",
    name: "Plátano",
    price: 5,
    group: "fruta",
    photo: "fotos/platano.webp",
  },
  {
    id: "cat-durazno-en-almibar",
    name: "Durazno en almíbar",
    price: 5,
    group: "fruta",
    photo: "fotos/durazno-en-almibar.webp",
  },
  {
    id: "cat-fresa",
    name: "Fresa",
    price: 5,
    group: "fruta",
    photo: "fotos/fresa.webp",
  },
  {
    id: "cat-queso-philadelphia",
    name: "Queso Philadelphia",
    price: 10,
    group: "relleno",
    photo: "fotos/queso-philadelphia.webp",
  },
  {
    id: "cat-mermelada-de-zarzamora",
    name: "Mermelada de zarzamora",
    price: 10,
    group: "relleno",
    photo: "fotos/mermelada-de-zarzamora.webp",
  },
  {
    id: "cat-cajeta",
    name: "Cajeta",
    price: 10,
    group: "relleno",
    photo: "fotos/cajeta.webp",
  },
  {
    id: "cat-lechera",
    name: "Lechera",
    price: 10,
    group: "relleno",
    photo: "fotos/lechera.webp",
  },
];
db.toppings ??= [];
if (isNewDatabase)
  for (const item of catalogV3) {
    const old = db.toppings.find(
      (t) => t.name.toLowerCase() === item.name.toLowerCase(),
    );
    if (!old) db.toppings.push(item);
    else if (!old.photo) old.photo = item.photo;
  }
function slugName(x) {
  return x
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-");
}
function addDefaultPhase(product, name, group, extras, free) {
  const id = "v3-" + product.id + "-" + slugName(name);
  if (db.phases.some((p) => p.id === id)) return;
  const ids = db.toppings
    .filter((t) => group.includes(t.group))
    .map((t) => t.id);
  db.phases.push({
    id,
    name,
    productIds: [product.id],
    optionIds: ids,
    multi: true,
    extras: !!extras,
    required: false,
    priceOverrides: free ? Object.fromEntries(ids.map((id) => [id, 0])) : {},
  });
}
if (isNewDatabase)
  db.phases = db.phases.filter((p) => !["p2", "p3", "p4"].includes(p.id));
if (isNewDatabase)
  for (const product of db.products) {
    if (product.category === "Fresas") {
      addDefaultPhase(product, "Toppings incluidos", ["normal"], false, true);
      addDefaultPhase(product, "Extras de toppings", ["normal"], true, false);
      addDefaultPhase(product, "Extras premium", ["premium"], true, false);
      addDefaultPhase(product, "Frutas extra", ["fruta"], true, false);
    } else if (product.category === "Crepas") {
      addDefaultPhase(product, "Rellenos", ["relleno"], true, true);
      addDefaultPhase(product, "Fruta incluida", ["fruta"], false, true);
      addDefaultPhase(product, "Topping incluido", ["normal"], false, true);
      addDefaultPhase(product, "Extras de toppings", ["normal"], true, false);
      addDefaultPhase(product, "Extras premium", ["premium"], true, false);
      addDefaultPhase(product, "Frutas extra", ["fruta"], true, false);
    }
  }
db.schemaVersion = 6;
lastSaved = JSON.stringify(db);
try {
  persistDatabase();
} catch (error) {
  console.error(error);
}
db.clients ??= [];
db.expenses ??= [];
db.debts ??= [];
db.suppliers ??= [];
function optionPrice(p, o) {
  return Number(p.priceOverrides?.[o.id] ?? o.price ?? 0);
}

function phaseOptions(p) {
  return (p.optionIds || [])
    .map((id) => db.toppings.find((t) => t.id === id))
    .filter(Boolean);
}
let role = "",
  tab = "venta",
  category = "Fresas",
  current = null,
  phaseIndex = 0,
  selected = {},
  cart = [],
  checkout = false;
const $ = (s) => document.querySelector(s),
  money = (n) => "$" + Number(n || 0).toFixed(2),
  esc = (s) =>
    String(s ?? "").replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[c],
    ),
  uid = () => Math.random().toString(36).slice(2, 10),
  save = persistDatabase,
  audit = (msg) => {
    db.audit.unshift({ at: new Date().toISOString(), role, msg });
    save();
  },
  isManager = () => role === "admin" || role === "trusted";
function img(src, label) {
  return src
    ? `<img src="${esc(src)}" alt="">`
    : `<div style="height:125px;background:linear-gradient(140deg,#f9dbe4,#fff3d9);display:grid;place-items:center;font-size:46px">${label === "Crepas" ? "🥞" : "🍓"}</div>`;
}
function render() {
  const navLeft = document.querySelector(".topnav")?.scrollLeft || 0;
  try {
    let root = $("#root");
    if (!role) {
      root.innerHTML = `<div class="login panel"><h2>🍓 Santo Antojo POS</h2><p class="muted">Sin conexión · Versión 1.4 · Inicia sesión</p><div class="field"><label>Tipo de acceso</label><select id="role"><option value="employee">Empleado</option><option value="trusted">Empleado de confianza</option><option value="admin">Administrador</option></select></div><div class="field"><label>PIN (administrador o confianza)</label><input id="pin" type="password" inputmode="numeric" placeholder="PIN"></div><button class="primary" style="width:100%" onclick="login()">Entrar</button><p class="footer">PIN inicial administrador: 1234 · confianza: 2468. Cámbialos en Ajustes antes de usar. Este acceso local no sustituye autenticación segura.</p></div>`;
      return;
    }
    root.innerHTML = `<header>${db.logo ? `<img src="${esc(db.logo)}">` : '<span style="font-size:33px">🍓</span>'}<strong>SANTO ANTOJO <span class="small">POS</span></strong><span class="spacer"></span><span class="small">${role === "admin" ? "Administrador" : role === "trusted" ? "Confianza" : "Empleado"}</span><button onclick="logout()">Salir</button></header><nav class="topnav">${[
      ["venta", "🛒 Venta"],
      ["campanas", "📣 Campañas IA"],
      ["historial", "📋 Ventas"],
      ["inventario", "📦 Inventario"],
      ["compras", "🚚 Compras"],
      ["recetas", "🧾 Recetas"],
      ["config", "⚙️ Configurar"],
      ["reportes", "📊 Reportes"],
      ["clientes", "👥 Clientes"],
      ["gastos", "💸 Gastos"],
      ["deudas", "📒 Fiados"],
      ["proveedores", "🏪 Proveedores"],
    ]
      .filter((x) => isManager() || ["venta", "historial"].includes(x[0]))
      .map(
        (x) =>
          `<button class="${tab === x[0] ? "active" : ""}" onclick="go('${x[0]}')">${x[1]}</button>`,
      )
      .join("")}</nav><div class="wrap" id="content"></div>`;
    ({
      venta: renderSale,
      campanas: renderCampaigns,
      historial: renderHistory,
      inventario: renderInventory,
      compras: renderPurchases,
      recetas: renderRecipes,
      config: renderConfig,
      reportes: renderReports,
      clientes: renderClients,
      gastos: renderExpenses,
      deudas: renderDebts,
      proveedores: renderSuppliers,
    })[tab]();
  } finally {
    const nav = document.querySelector(".topnav");
    if (nav) nav.scrollLeft = navLeft;
    document.querySelectorAll(".scroll").forEach((el) => {
      el.setAttribute("tabindex", "0");
      el.setAttribute("aria-label", "Lista deslizable");
      if (el.querySelector("table")) {
        const hint = document.createElement("p");
        hint.className = "scroll-hint";
        hint.textContent =
          "Desliza la tabla hacia los lados y hacia abajo para ver más.";
        el.before(hint);
      }
    });
    document
      .querySelectorAll("input[type=number]")
      .forEach((el) => el.setAttribute("inputmode", "decimal"));
  }
}
function login() {
  let r = $("#role").value,
    p = $("#pin").value;
  if (
    (r === "admin" && p !== db.pin) ||
    (r === "trusted" && p !== db.trustedPin)
  ) {
    alert("PIN incorrecto");
    return;
  }
  role = r;
  render();
  if (isManager()) maybeCheckForAppUpdate();
}
function logout() {
  if (
    cart.length &&
    !confirm("Hay un pedido sin cobrar. ¿Descartarlo y cerrar sesión?")
  )
    return;
  role = "";
  cart = [];
  current = null;
  checkout = false;
  document.querySelector(".cart-link")?.remove();
  render();
}
function go(t) {
  tab = t;
  current = null;
  checkout = false;
  document.querySelector(".cart-link")?.remove();
  render();
  window.scrollTo(0, 0);
}
function activePhases() {
  return db.phases.filter((p) => (p.productIds || []).includes(current.id));
}
function currentPrice() {
  return (
    Math.round(
      (Number(current.price) +
        activePhases().reduce(
          (sum, p) =>
            sum +
            phaseOptions(p).reduce(
              (s, o) => s + (selected[p.id]?.[o.id] || 0) * optionPrice(p, o),
              0,
            ),
          0,
        )) *
        100,
    ) / 100
  );
}
function renderSale() {
  let el = $("#content");
  el.innerHTML = `<div class="layout"><section class="panel"><div id="sell"></div></section><aside class="panel cart"><h2>🛒 Pedido <span class="pill">${cart.length}</span></h2><div id="cart"></div></aside></div>`;
  renderSell();
  renderCart();
}
function renderSell() {
  let e = $("#sell");
  if (checkout) {
    e.innerHTML = `<h2>Cobrar pedido</h2><p>Total: <strong class="tot">${money(cartTotal())}</strong></p><p class="muted">Puedes combinar efectivo, transferencia y tarjeta.</p>${[
      ["cash", "Efectivo"],
      ["transfer", "Transferencia"],
      ["card", "Tarjeta"],
    ]
      .map(
        (x) =>
          `<div class="field"><label>${x[1]}</label><input type="number" min="0" step="0.01" id="${x[0]}" value="${x[0] === "cash" ? cartTotal() : 0}" oninput="updateChange()"></div>`,
      )
      .join(
        "",
      )}<p id="change"></p><div class="actions"><button onclick="checkout=false;renderSell()">Volver</button><button class="primary" onclick="pay()">Confirmar venta</button></div>`;
    updateChange();
    return;
  }
  if (!current) {
    if (!db.products.some((p) => p.category === category))
      category = db.products[0]?.category || "";
    e.innerHTML = `<h2>Seleccionar producto</h2><div class="row" style="margin-bottom:15px">${[...new Set(db.products.map((p) => p.category))].map((c, index) => `<button class="${category === c ? "primary" : ""}" onclick="selectCategory(${index})">${esc(c)}</button>`).join("")}</div><div class="grid">${db.products
      .filter((p) => p.category === category)
      .map(
        (p) =>
          `<button class="product" onclick="start('${p.id}')">${img(p.photo, p.category)}<div class="details"><b>${esc(p.name)}</b><span class="price">${money(p.price)}</span></div></button>`,
      )
      .join("")}</div>`;
    return;
  }
  let phases = activePhases();
  if (phaseIndex >= phases.length) {
    e.innerHTML = `<h2>Confirmar: ${esc(current.name)}</h2><p>Precio base: ${money(current.price)}</p>${phases
      .map(
        (p) =>
          `<p><b>${esc(p.name)}:</b> ${
            phaseOptions(p)
              .filter((o) => selected[p.id]?.[o.id])
              .map((o) => `${esc(o.name)} ×${selected[p.id][o.id]}`)
              .join(", ") || "Sin selección"
          }</p>`,
      )
      .join(
        "",
      )}<h2>Total: ${money(currentPrice())}</h2><div class="actions"><button onclick="prev()">← Regresar</button><button class="primary" onclick="addCart()">Agregar al pedido ✓</button></div>`;
    return;
  }
  let p = phases[phaseIndex];
  e.innerHTML = `<div class="muted">${esc(current.name)} · Fase ${phaseIndex + 1} de ${phases.length}</div><div class="step">${phases.map((_, i) => `<span class="${i <= phaseIndex ? "done" : ""}"></span>`).join("")}</div><h2>${esc(p.name)}</h2><p class="muted">${p.extras ? "Elige cualquier extra y aumenta sus porciones." : p.multi ? "Puedes elegir varias opciones." : "Selecciona una opción."} ${p.required ? "Obligatorio" : "Opcional"}</p><div class="option-list" aria-label="Opciones de la fase" tabindex="0">${
    phaseOptions(p).length
      ? phaseOptions(p)
          .map(
            (o) =>
              `<div class="choice ${selected[p.id]?.[o.id] || 0 ? "selected" : ""}" onclick="pick('${p.id}','${o.id}',${p.multi || p.extras})">${o.photo ? `<img src="${esc(o.photo)}">` : '<span style="font-size:34px">🍫</span>'}<div class="grow"><b>${esc(o.name)}</b><div class="muted">${optionPrice(p, o) ? `+${money(optionPrice(p, o))} por porción` : "Incluido"}</div></div>${p.extras ? `<div class="qty"><button onclick="event.stopPropagation();changeQty('${p.id}','${o.id}',-1)">−</button><b>${selected[p.id]?.[o.id] || 0}</b><button onclick="event.stopPropagation();changeQty('${p.id}','${o.id}',1)">+</button></div>` : `<b>${selected[p.id]?.[o.id] ? "✓" : "○"}</b>`}</div>`,
          )
          .join("")
      : '<p class="notice">Aún no hay opciones. Agrégalas en Configurar → Fases.</p>'
  }</div><div class="step-actions"><div class="flex"><b>Total: ${money(currentPrice())}</b><span class="muted">${phaseIndex + 1}/${phases.length}</span></div><div class="actions"><button onclick="prev()">← Atrás</button><button class="primary" onclick="next()">Siguiente →</button></div></div>`;
}
function start(id) {
  current = db.products.find((p) => p.id === id);
  if (!current) return;
  selected = {};
  phaseIndex = 0;
  checkout = false;
  renderSell();
  scrollToSale();
}
function pick(pid, oid, multi) {
  const scroll = $(".option-list")?.scrollTop || 0;
  selected[pid] ??= {};
  const was = !!selected[pid][oid];
  if (!multi) selected[pid] = {};
  selected[pid][oid] = was ? 0 : 1;
  renderSell();
  if ($(".option-list")) $(".option-list").scrollTop = scroll;
}
function changeQty(pid, oid, n) {
  const scroll = $(".option-list")?.scrollTop || 0;
  selected[pid] ??= {};
  selected[pid][oid] = Math.max(
    0,
    Math.min(999, (selected[pid][oid] || 0) + n),
  );
  renderSell();
  if ($(".option-list")) $(".option-list").scrollTop = scroll;
}
function prev() {
  if (phaseIndex > 0) phaseIndex--;
  else current = null;
  renderSell();
  scrollToSale();
}
function next() {
  const p = activePhases()[phaseIndex];
  if (p?.required && !Object.values(selected[p.id] || {}).some(Boolean)) {
    alert("Selecciona una opción para continuar");
    return;
  }
  phaseIndex++;
  renderSell();
  scrollToSale();
}
function addCart() {
  cart.push({
    id: uid(),
    productId: current.id,
    name: current.name,
    price: currentPrice(),
    choices: structuredClone(selected),
    description: activePhases().flatMap((p) =>
      phaseOptions(p)
        .filter((o) => selected[p.id]?.[o.id])
        .map((o) => `${p.name}: ${o.name} ×${selected[p.id][o.id]}`),
    ),
  });
  current = null;
  renderSell();
  renderCart();
}
function renderCart() {
  try {
    let e = $("#cart");
    e.innerHTML = cart.length
      ? cart
          .map(
            (x, i) =>
              `<div class="cartline"><div class="flex"><b>${esc(x.name)}</b><b>${money(x.price)}</b></div><div class="muted">${x.description.map(esc).join(" · ") || "Sin extras"}</div><button class="small" onclick="removeCartLine(${i})">Quitar</button></div>`,
          )
          .join("") +
        `<div class="flex" style="margin:16px 0"><b>Total</b><span class="tot">${money(cartTotal())}</span></div><button class="primary" style="width:100%" onclick="checkout=true;renderSell();scrollToSale()">Cobrar pedido</button><button style="width:100%;margin-top:8px" onclick="emptyCart()">Vaciar</button>`
      : '<p class="muted">Todavía no hay productos.</p>';
  } finally {
    document.querySelector(".cart-link")?.remove();
    if (cart.length && tab === "venta" && role) {
      const link = document.createElement("button");
      link.className = "cart-link";
      link.innerHTML =
        "<span>🛒 Ver pedido · " +
        cart.length +
        "</span><strong>" +
        money(cart.reduce((s, x) => s + x.price, 0)) +
        "</strong>";
      link.onclick = () =>
        document
          .querySelector(".cart")
          ?.scrollIntoView({ behavior: "smooth", block: "start" });
      document.body.append(link);
    }
  }
}
function updateChange() {
  let t = cartTotal(),
    paid = ["cash", "transfer", "card"].reduce(
      (s, k) => s + Number($("#" + k)?.value || 0),
      0,
    );
  $("#change").textContent =
    `Recibido: ${money(paid)} · Cambio: ${money(Math.max(0, paid - t))} · Falta: ${money(Math.max(0, t - paid))}`;
}
function pay() {
  if (!cart.length) {
    alert("Agrega un producto antes de cobrar.");
    checkout = false;
    renderSell();
    return;
  }
  let t = cartTotal(),
    payments = Object.fromEntries(
      ["cash", "transfer", "card"].map((k) => [
        k,
        Number($("#" + k).value || 0),
      ]),
    ),
    paid = Object.values(payments).reduce((a, b) => a + b, 0);
  if (
    Object.values(payments).some((x) => !Number.isFinite(x) || x < 0) ||
    paid + 0.001 < t
  ) {
    alert("El pago no cubre el total");
    return;
  }
  if (payments.transfer + payments.card > t + 0.001) {
    alert(
      "La transferencia y la tarjeta no pueden superar el total. El cambio solo se entrega sobre el efectivo.",
    );
    return;
  }
  let unconfigured = cart.filter(
    (x) => !Object.values(db.recipes[x.productId] || {}).some((v) => v > 0),
  );
  if (
    unconfigured.length &&
    !confirm(
      "Hay productos sin receta base: " +
        unconfigured.map((x) => x.name).join(", ") +
        ".\nSu consumo y costo pueden estar incompletos. ¿Continuar?",
    )
  )
    return;
  let needs = calcNeeds(cart),
    low = Object.entries(needs).filter(([id, q]) => {
      let x = db.inventory.find((i) => i.id === id);
      return x && x.stock < q;
    });
  if (
    low.length &&
    !confirm(
      "Existencias insuficientes:\n" +
        low
          .map(([id, q]) => {
            let x = db.inventory.find((i) => i.id === id);
            return (
              x.name +
              ": requiere " +
              nfmt(q) +
              " " +
              x.unit +
              ", disponible " +
              nfmt(x.stock)
            );
          })
          .join("\n") +
        "\n\n¿Registrar venta de todas formas? El inventario quedará negativo.",
    )
  )
    return;
  let cost = Object.entries(needs).reduce(
    (v, [id, q]) =>
      v + q * getCost(db.inventory.find((x) => x.id === id) || {}),
    0,
  );
  let sale = {
    id: uid(),
    at: new Date().toISOString(),
    items: structuredClone(cart),
    total: t,
    payments,
    change: Math.max(0, Math.round((paid - t) * 100) / 100),
    operator: role,
    ingredientUsage: needs,
    estimatedCost: cost,
  };
  db.sales.unshift(sale);
  for (const [id, q] of Object.entries(needs))
    stockMove(id, -q, "Venta", sale.id, "Consumo según receta");
  audit("Venta " + sale.id + " por " + money(t));
  cart = [];
  checkout = false;
  current = null;
  render();
  if (confirm("Venta guardada. ¿Imprimir ticket?")) printTicket(sale, false);
}
function printTicket(sale, kitchen) {
  if (!sale) return alert("No se encontró la venta.");
  const lines = sale.items
    .map(
      (x) =>
        `<p><b>${esc(x.name)}</b> ${kitchen ? "" : money(x.price)}<br>${x.description.map(esc).join("<br>")}</p>`,
    )
    .join("");
  const html = `<!doctype html><html lang="es"><head><meta charset="utf-8"><title>${kitchen ? "Comanda" : "Ticket"} Santo Antojo</title><style>body{font:14px monospace;max-width:72mm;margin:5mm auto;padding:3mm}h2{text-align:center}hr{border:0;border-top:1px dashed #333}</style></head><body><h2>SANTO ANTOJO</h2><p>${kitchen ? "COMANDA DE PREPARACIÓN" : "TICKET DE VENTA"}${sale.void ? " · CANCELADA" : ""}</p><p>${new Date(sale.at).toLocaleString("es-MX")} · ${esc(sale.id)}</p><hr>${lines}<hr>${kitchen ? "" : `<b>TOTAL ${money(sale.total)}</b><p>Cambio: ${money(sale.change)}</p>`}<p>Gracias por tu compra</p></body></html>`;
  if (window.SantoAndroid?.printHtml) {
    SantoAndroid.printHtml(html);
    return;
  }
  const w = window.open("", "_blank");
  if (!w) {
    alert("Permite ventanas emergentes para imprimir.");
    return;
  }
  w.document.write(html);
  w.document.close();
  w.onload = () => {
    w.focus();
    w.print();
  };
}
function renderHistory() {
  $("#content").innerHTML =
    `<div class="panel"><h2>Historial de ventas</h2><div class="scroll"><table class="table"><tr><th>Fecha</th><th>Folio</th><th>Total</th><th>Acciones</th></tr>${db.sales.map((s) => `<tr><td>${new Date(s.at).toLocaleString("es-MX")}</td><td>${s.id}</td><td>${money(s.total)}${s.void ? '<br><span class="pill">Cancelada</span>' : ""}</td><td><button onclick="printSale('${s.id}',false)">Ticket</button> <button onclick="printSale('${s.id}',true)">Comanda</button> ${role === "admin" && !s.void ? `<button onclick="voidSale('${s.id}')">Cancelar</button>` : ""}</td></tr>`).join("")}</table></div></div>`;
}
function printSale(id, k) {
  printTicket(
    db.sales.find((s) => s.id === id),
    k,
  );
}
function voidSale(id) {
  let pin = prompt("PIN del administrador para cancelar");
  if (pin !== db.pin) {
    alert("PIN incorrecto");
    return;
  }
  let s = db.sales.find((x) => x.id === id);
  if (!s || s.void) {
    alert("No se puede cancelar");
    return;
  }
  if (confirm("¿Cancelar venta? Quedará registrada.")) {
    s.void = true;
    for (const [ingredientId, qty] of Object.entries(s.ingredientUsage || {}))
      stockMove(
        ingredientId,
        qty,
        "Cancelación",
        s.id,
        "Reintegro por cancelación",
      );
    audit("Cancelación " + id);
    render();
  }
}

function nfmt(v) {
  return Number(v || 0).toLocaleString("es-MX", { maximumFractionDigits: 3 });
}
function getCost(x) {
  return Number(x.cost || 0);
}
function recipeLines(item) {
  let lines = [];
  for (const [id, qty] of Object.entries(db.recipes[item.productId] || {})) {
    if (qty > 0) lines.push({ id, qty });
  }
  for (const [phaseId, opts] of Object.entries(item.choices || {}))
    for (const [optionId, count] of Object.entries(opts)) {
      if (count > 0)
        for (const [id, qty] of Object.entries(
          db.optionRecipes[optionId] || {},
        )) {
          if (qty > 0) lines.push({ id, qty: qty * count });
        }
    }
  return lines;
}
function calcNeeds(items) {
  let map = {};
  for (const item of items)
    for (const x of recipeLines(item)) map[x.id] = (map[x.id] || 0) + x.qty;
  return map;
}
function stockMove(id, delta, kind, ref, note) {
  let x = db.inventory.find((i) => i.id === id);
  if (!x) return;
  x.stock = Math.round((Number(x.stock || 0) + delta) * 100000) / 100000;
  db.stockMoves.unshift({
    id: uid(),
    ingredientId: id,
    delta,
    kind,
    ref,
    note,
    at: new Date().toISOString(),
    operator: role,
  });
}
function renderInventory() {
  let low = db.inventory.filter((x) => Number(x.stock) <= Number(x.min || 0));
  $("#content").innerHTML =
    `<div class="panel"><h2>📦 Inventario inteligente</h2><p class="muted">Existencias, mínimos, costos unitarios y movimientos. Configura recetas para descontar insumos al vender.</p>
 <div class="row"><input id="iname" placeholder="Ingrediente" style="max-width:200px"><input id="istock" type="number" step=".001" min="0" placeholder="Existencia" style="max-width:130px"><input id="iunit" placeholder="Unidad: g, ml, pza..." style="max-width:170px"><input id="imin" type="number" step=".001" min="0" placeholder="Mínimo" style="max-width:120px"><input id="icost" type="number" step=".001" min="0" placeholder="Costo por unidad" style="max-width:150px"><button class="primary" onclick="addInventory()">Agregar insumo</button></div>
 <p class="notice">${low.length ? "⚠️ Insumos en mínimo o agotados: " + low.map((x) => esc(x.name)).join(", ") : "Sin alertas de mínimo por ahora."}</p>
 <div class="scroll"><table class="table"><tr><th>Ingrediente</th><th>Disponible</th><th>Mínimo</th><th>Costo unitario</th><th>Estado</th><th>Acciones</th></tr>
 ${db.inventory.map((x) => `<tr><td>${esc(x.name)}</td><td>${nfmt(x.stock)} ${esc(x.unit)}</td><td>${nfmt(x.min)} ${esc(x.unit)}</td><td>${money(x.cost)} / ${esc(x.unit)}</td><td>${Number(x.stock) <= Number(x.min) ? "⚠️ Bajo" : "✓ Bien"}</td><td><button onclick="editStock('${x.id}')">Ajustar / merma</button> <button onclick="editIngredient('${x.id}')">Editar</button></td></tr>`).join("")}</table></div>
 <h3>Movimientos recientes</h3><div class="scroll"><table class="table"><tr><th>Fecha</th><th>Insumo</th><th>Movimiento</th><th>Motivo</th></tr>${db.stockMoves
   .slice(0, 60)
   .map(
     (m) =>
       `<tr><td>${new Date(m.at).toLocaleString("es-MX")}</td><td>${esc(db.inventory.find((x) => x.id === m.ingredientId)?.name || "Insumo eliminado")}</td><td>${m.delta > 0 ? "+" : ""}${nfmt(m.delta)}</td><td>${esc(m.kind)} ${esc(m.note || "")}</td></tr>`,
   )
   .join("")}</table></div></div>`;
}
function addInventory() {
  let name = $("#iname").value.trim(),
    stock = Number($("#istock").value),
    unit = $("#iunit").value.trim(),
    min = Number($("#imin").value || 0),
    cost = Number($("#icost").value || 0);
  if (
    !name ||
    !unit ||
    [stock, min, cost].some((v) => !Number.isFinite(v) || v < 0)
  )
    return alert("Revisa los datos y las cantidades");
  if (db.inventory.some((x) => x.name.toLowerCase() === name.toLowerCase()))
    return alert("Ese insumo ya existe");
  let id = uid();
  db.inventory.push({ id, name, stock, unit, min, cost });
  db.stockMoves.unshift({
    id: uid(),
    ingredientId: id,
    delta: stock,
    kind: "Existencia inicial",
    at: new Date().toISOString(),
    operator: role,
  });
  audit("Agregó insumo " + name);
  render();
}
function editIngredient(id) {
  let x = db.inventory.find((i) => i.id === id);
  if (!x) return;
  let a = prompt("Nombre del insumo", x.name);
  if (a === null || !a.trim()) return;
  let m = prompt("Existencia mínima (" + x.unit + ")", x.min),
    c = prompt("Costo por " + x.unit + " (MXN)", x.cost);
  if (m === null || c === null) return;
  let min = Number(m),
    cost = Number(c);
  if ([min, cost].some((v) => !Number.isFinite(v) || v < 0))
    return alert("Valor inválido");
  x.name = a.trim();
  x.min = min;
  x.cost = cost;
  audit("Editó insumo " + x.name);
  render();
}
function editStock(id) {
  let x = db.inventory.find((i) => i.id === id);
  if (!x) return;
  let v = prompt(
    "Nueva existencia de " +
      x.name +
      " (" +
      x.unit +
      "). Se registrará el ajuste.",
    x.stock,
  );
  if (v === null) return;
  let n = Number(v);
  if (!Number.isFinite(n) || n < 0) return alert("Cantidad inválida");
  let reason = prompt("Motivo: merma, conteo, corrección...", "Ajuste manual");
  if (reason === null) return;
  stockMove(id, n - x.stock, "Ajuste", null, reason);
  audit("Ajustó " + x.name);
  render();
}
function renderRecipes() {
  let missing = db.products.filter(
    (p) => !Object.values(db.recipes[p.id] || {}).some((v) => v > 0),
  ).length;
  $("#content").innerHTML =
    `<div class="panel"><h2>🧾 Recetas y consumo automático</h2><p class="muted">Configura cantidades por cada producto base y por cada porción de topping. Se descuentan cuando se cobra una venta.</p><p class="notice">⚠️ ${missing} productos sin receta base. Una receta incompleta no puede descontar todos sus ingredientes.</p>
 <h3>Recetas de productos</h3>${db.products.map((x) => `<div class="flex" style="border-bottom:1px solid #eee;padding:10px"><span><b>${esc(x.name)}</b><br><span class="muted">Costo base estimado: ${money(recipeCost(db.recipes[x.id]))}</span></span><button onclick="editRecipe('product','${x.id}')">Configurar ingredientes</button></div>`).join("")}
 <h3>Recetas de toppings, frutas y extras</h3><p class="muted">Una receta por porción, reutilizada en todas las fases.</p><div class="scroll" style="max-height:500px">${db.toppings.map((x) => `<div class="flex" style="border-bottom:1px solid #eee;padding:8px"><span>${esc(x.name)} <span class="muted">· costo ${money(recipeCost(db.optionRecipes[x.id]))}</span></span><button onclick="editRecipe('option','${x.id}')">Configurar</button></div>`).join("")}</div></div>`;
}
function recipeCost(map) {
  return Object.entries(map || {}).reduce(
    (s, [id, q]) => s + (db.inventory.find((x) => x.id === id)?.cost || 0) * q,
    0,
  );
}
function editRecipe(type, id) {
  if (!db.inventory.length)
    return alert("Primero agrega ingredientes en Inventario.");
  const item = (type === "product" ? db.products : db.toppings).find(
    (x) => x.id === id,
  );
  if (!item) return;
  const source = type === "product" ? db.recipes : db.optionRecipes,
    values = source[id] || {};
  openModal(
    "Receta: " + item.name,
    `<p class="muted">Cantidad que se consume por producto o por porción. Usa 0 para quitar un ingrediente.</p><input class="search" type="search" placeholder="Buscar ingrediente" oninput="filterModal(this.value)">${db.inventory.map((x) => `<div class="recipe-row filter-row" data-search="${esc(x.name.toLocaleLowerCase("es"))}"><label for="recipe-${x.id}"><b>${esc(x.name)}</b><br><span class="muted">${esc(x.unit)}</span></label><input id="recipe-${x.id}" data-ingredient="${x.id}" type="number" min="0" step="any" inputmode="decimal" value="${Number(values[x.id] || 0)}"></div>`).join("")}`,
    () => {
      const next = {};
      for (const input of document.querySelectorAll("[data-ingredient]")) {
        const n = Number(input.value);
        if (!Number.isFinite(n) || n < 0) {
          alert("Revisa las cantidades: deben ser 0 o mayores.");
          input.focus();
          return false;
        }
        if (n > 0) next[input.dataset.ingredient] = n;
      }
      source[id] = next;
      audit("Configuró receta " + item.name);
      renderRecipes();
      toast("Receta guardada");
    },
  );
}
function renderPurchases() {
  $("#content").innerHTML =
    `<div class="panel"><h2>🚚 Compras y entradas de inventario</h2><p class="muted">Registra compras con ingreso directo al inventario. El costo unitario se actualiza con la última compra.</p>
 <div class="row"><input id="supplier" placeholder="Proveedor" style="max-width:180px"><select id="buyingredient"><option value="">Selecciona insumo</option>${db.inventory.map((x) => `<option value="${x.id}">${esc(x.name)} (${esc(x.unit)})</option>`).join("")}</select><input id="buyqty" type="number" step=".001" min="0" placeholder="Cantidad comprada"><input id="amount" type="number" step=".01" min="0" placeholder="Total MXN"><button class="primary" onclick="addPurchase()">Registrar entrada</button></div>
 <div class="scroll"><table class="table"><tr><th>Fecha</th><th>Proveedor</th><th>Insumo</th><th>Cantidad</th><th>Total</th></tr>${db.purchases.map((x) => `<tr><td>${new Date(x.at).toLocaleDateString("es-MX")}</td><td>${esc(x.supplier)}</td><td>${esc(x.detail || db.inventory.find((i) => i.id === x.ingredientId)?.name || "")}</td><td>${nfmt(x.qty || 0)}</td><td>${money(x.amount)}</td></tr>`).join("")}</table></div></div>`;
}
function addPurchase() {
  let supplier = $("#supplier").value.trim(),
    id = $("#buyingredient").value,
    qty = Number($("#buyqty").value),
    amount = Number($("#amount").value);
  if (
    !supplier ||
    !id ||
    !Number.isFinite(qty) ||
    qty <= 0 ||
    !Number.isFinite(amount) ||
    amount < 0
  )
    return alert("Completa proveedor, insumo, cantidad y costo");
  let x = db.inventory.find((i) => i.id === id);
  if (!x) return;
  let purchaseId = uid();
  db.purchases.unshift({
    id: purchaseId,
    at: new Date().toISOString(),
    supplier,
    ingredientId: id,
    detail: x.name,
    qty,
    amount,
  });
  stockMove(id, qty, "Compra", purchaseId, supplier);
  x.cost = amount / qty;
  audit("Compra de " + x.name);
  render();
}
function renderConfig() {
  if (!isManager()) return go("venta");
  $("#content").innerHTML =
    `<div class="panel"><h2>Personalizar menú</h2><p class="muted">Cada producto tiene sus propias fases. Crea los toppings una sola vez y asígnalos a las fases que quieras.</p>
<h3>Productos</h3><div class="scroll"><table class="table">${db.products.map((p) => `<tr><td>${esc(p.name)} · ${esc(p.category)}</td><td>${money(p.price)}</td><td><button onclick="editProduct('${p.id}')">Editar</button> <button onclick="removeProduct('${p.id}')">Quitar</button></td></tr>`).join("")}</table></div><button class="primary" onclick="editProduct()">+ Agregar producto</button>
<hr><h3>Biblioteca de toppings y opciones</h3><input type="search" class="search" placeholder="Buscar en la biblioteca" oninput="document.querySelectorAll('.catalog-list > .flex').forEach(x=>x.hidden=!x.textContent.toLocaleLowerCase('es').includes(this.value.toLocaleLowerCase('es')))"><p class="muted">Agrega una opción una sola vez. Su nombre, fotografía y precio se reutilizan en cualquier fase.</p>
<div class="catalog-list">${db.toppings.map((o) => `<div class="flex" style="padding:8px;border-bottom:1px solid #eee"><span>${o.photo ? `<img class="thumb" src="${esc(o.photo)}">` : ""} ${esc(o.name)} · ${esc(o.group || "personalizado")} · ${money(o.price)}</span><span><button onclick="editTopping('${o.id}')">Editar</button> <button onclick="removeTopping('${o.id}')">Quitar</button></span></div>`).join("")}
</div><button class="primary" style="margin-top:10px" onclick="editTopping()">+ Agregar topping / opción</button>
<hr><h3>Fases independientes por producto</h3>
${db.products
  .map(
    (
      prod,
    ) => `<div class="panel" style="margin:12px 0"><h3>${esc(prod.name)}</h3>
${db.phases
  .filter((p) => (p.productIds || []).includes(prod.id))
  .map(
    (p) =>
      `<div style="padding:10px;margin:8px 0;border:1px solid #ead5da;border-radius:12px"><div class="flex"><b>${esc(p.name)}</b><span><button onclick="editPhase('${p.id}')">Editar</button> <button onclick="removePhase('${p.id}')">Quitar</button></span></div><p class="muted">${p.extras ? "Extras con cantidades" : p.multi ? "Selección múltiple" : "Selección única"} · ${
        phaseOptions(p)
          .map((o) => esc(o.name))
          .join(", ") || "Sin opciones"
      }</p><button onclick="assignToppings('${p.id}')">Elegir opciones de mi biblioteca</button> <button onclick="setIncluded('${p.id}')">Precio en esta fase</button></div>`,
  )
  .join("")}
<button class="primary" onclick="editPhase(null,'${prod.id}')">+ Agregar fase a ${esc(prod.name)}</button></div>`,
  )
  .join("")}
<hr><h3>Imagen de marca</h3><input type="file" accept="image/*" onchange="uploadImage(this,f=>{db.logo=f;save();render()})">
${role === "admin" ? `<hr><h3>PIN de acceso</h3><button onclick="changePin('pin')">Cambiar PIN administrador</button> <button onclick="changePin('trustedPin')">Cambiar PIN confianza</button>` : ""}
<hr><h3>📲 Actualizaciones</h3>
<p class="muted">Actualiza Santo Antojo desde la app, sin descargar archivos ZIP. Android te pedirá confirmar la instalación. Las ventas se mantienen si la actualización está firmada con el mismo certificado.</p>
<div class="field"><label>Dirección HTTPS de actualizaciones (se configura una sola vez)</label><input type="url" id="update-feed-url" placeholder="https://tu-servidor.mx/actualizaciones/update.json" value="${esc(localStorage.getItem('santo_antojo_update_feed')||'')}"></div>
<div class="actions"><button onclick="saveUpdateFeed()">Guardar dirección</button><button class="primary" onclick="checkForAppUpdate(false)">Buscar actualizaciones</button></div>
<p class="muted" id="update-state" role="status">Versión instalada: 1.4. Sin servidor configurado no habrá avisos automáticos.</p>
<hr><h3>Respaldo</h3><div class="actions"><button onclick="exportData()">Exportar respaldo JSON</button><label style="padding:12px;background:#f4e6e8;border-radius:12px;cursor:pointer">Importar respaldo<input style="display:none" type="file" accept="application/json,.json" onchange="importData(this)"></label></div><p class="notice">Datos locales en este dispositivo. Exporta respaldos regularmente.</p></div>`;
}
function ask(label, value) {
  return prompt(label, value ?? "");
}
function editProduct(id) {
  const old = db.products.find((x) => x.id === id);
  openModal(
    old ? "Editar producto" : "Nuevo producto",
    `<div class="field"><label for="edit-name">Nombre</label><input id="edit-name" maxlength="100" value="${esc(old?.name || "")}"></div><div class="field"><label for="edit-category">Categoría</label><input id="edit-category" maxlength="60" value="${esc(old?.category || "Fresas")}"></div><div class="field"><label for="edit-price">Precio base (MXN)</label><input id="edit-price" type="number" min="0" step="0.01" inputmode="decimal" value="${old?.price || 0}"></div><label class="check-row"><input id="edit-photo" type="checkbox">Elegir o cambiar fotografía después de guardar</label>`,
    () => {
      const name = $("#edit-name").value.trim(),
        cat = $("#edit-category").value.trim(),
        raw = $("#edit-price").value,
        price = Number(raw),
        photo = $("#edit-photo").checked;
      if (!name || !cat || raw === "" || !Number.isFinite(price) || price < 0) {
        alert("Completa el nombre, la categoría y un precio válido.");
        return false;
      }
      const item = old || { id: uid(), photo: "" };
      if (!old) db.products.push(item);
      Object.assign(item, { name, category: cat, price });
      audit("Editó producto " + name);
      renderConfig();
      if (photo)
        setTimeout(
          () =>
            chooseImage((f) => {
              item.photo = f;
              save();
              renderConfig();
            }),
          0,
        );
    },
  );
}
function removeProduct(id) {
  if (!confirm("¿Quitar producto del menú?")) return;
  db.products = db.products.filter((p) => p.id !== id);
  audit("Quitó producto " + id);
  render();
}
function editPhase(id, productId) {
  const old = db.phases.find((x) => x.id === id),
    mode = old?.extras ? "extras" : old?.multi ? "multiple" : "unica";
  openModal(
    old ? "Editar fase" : "Nueva fase",
    `<div class="field"><label for="edit-name">Nombre</label><input id="edit-name" maxlength="100" value="${esc(old?.name || "")}"></div><div class="field"><label for="edit-mode">Tipo de selección</label><select id="edit-mode">${[
      ["unica", "Una opción"],
      ["multiple", "Varias opciones"],
      ["extras", "Extras con cantidades"],
    ]
      .map(
        ([v, n]) =>
          `<option value="${v}" ${v === mode ? "selected" : ""}>${n}</option>`,
      )
      .join(
        "",
      )}</select></div><label class="check-row"><input type="checkbox" id="edit-required" ${old?.required ? "checked" : ""}>Obligatorio elegir al menos una opción</label>`,
    () => {
      const name = $("#edit-name").value.trim(),
        mode = $("#edit-mode").value;
      if (!name) {
        alert("Escribe el nombre de la fase.");
        return false;
      }
      const p = old || {
        id: uid(),
        productIds: [productId],
        optionIds: [],
        priceOverrides: {},
      };
      if (!old) db.phases.push(p);
      Object.assign(p, {
        name,
        multi: mode !== "unica",
        extras: mode === "extras",
        required: $("#edit-required").checked,
      });
      audit("Editó fase " + name);
      renderConfig();
    },
  );
}
function removePhase(id) {
  if (
    !confirm(
      "¿Eliminar esta fase? Los toppings de la biblioteca se conservarán.",
    )
  )
    return;
  db.phases = db.phases.filter((x) => x.id !== id);
  audit("Quitó fase " + id);
  render();
}
function editTopping(id) {
  const old = db.toppings.find((x) => x.id === id);
  openModal(
    old ? "Editar topping" : "Nuevo topping",
    `<div class="field"><label for="edit-name">Nombre</label><input id="edit-name" maxlength="100" value="${esc(old?.name || "")}"></div><div class="field"><label for="edit-price">Precio por porción (MXN)</label><input id="edit-price" type="number" min="0" step="0.01" inputmode="decimal" value="${old?.price || 0}"></div><label class="check-row"><input id="edit-photo" type="checkbox">Elegir o cambiar fotografía después de guardar</label>`,
    () => {
      const name = $("#edit-name").value.trim(),
        raw = $("#edit-price").value,
        price = Number(raw),
        photo = $("#edit-photo").checked;
      if (!name || raw === "" || !Number.isFinite(price) || price < 0) {
        alert("Completa el nombre y un precio válido.");
        return false;
      }
      const item = old || { id: uid(), photo: "", group: "personalizado" };
      if (!old) db.toppings.push(item);
      Object.assign(item, { name, price });
      audit("Editó topping " + name);
      renderConfig();
      if (photo)
        setTimeout(
          () =>
            chooseImage((f) => {
              item.photo = f;
              save();
              renderConfig();
            }),
          0,
        );
    },
  );
}
function removeTopping(id) {
  if (!confirm("¿Quitar esta opción de la biblioteca y todas las fases?"))
    return;
  db.toppings = db.toppings.filter((x) => x.id !== id);
  db.phases.forEach((p) => (p.optionIds = p.optionIds.filter((x) => x !== id)));
  audit("Quitó topping " + id);
  render();
}
function setIncluded(pid) {
  const p = db.phases.find((x) => x.id === pid);
  if (!p) return;
  openModal(
    "Precio en " + p.name,
    `<p class="muted">Deja vacío para usar el precio de la biblioteca. Escribe 0 para incluir las opciones sin costo extra.</p><div class="field"><label for="phase-price">Precio por opción (MXN)</label><input id="phase-price" type="number" min="0" step="0.01" inputmode="decimal" placeholder="Precio de biblioteca" value="${p.optionIds.length && p.optionIds.every((id) => p.priceOverrides?.[id] === p.priceOverrides?.[p.optionIds[0]]) ? esc(p.priceOverrides?.[p.optionIds[0]] ?? "") : ""}"></div>`,
    () => {
      const raw = $("#phase-price").value.trim(),
        n = Number(raw);
      if (raw !== "" && (!Number.isFinite(n) || n < 0)) {
        alert("Precio inválido");
        return false;
      }
      const prices = {};
      if (raw !== "") for (const id of p.optionIds) prices[id] = n;
      p.priceOverrides = prices;
      audit("Cambió precios fase " + p.name);
      renderConfig();
    },
  );
}
function assignToppings(pid) {
  const p = db.phases.find((x) => x.id === pid);
  if (!p) return;
  if (!db.toppings.length)
    return alert("Primero crea opciones en la biblioteca.");
  openModal(
    "Opciones: " + p.name,
    `<p class="muted">Marca las opciones de esta fase. Desliza para ver toda la lista.</p><input type="search" class="search" placeholder="Buscar topping o fruta" oninput="filterModal(this.value)">${db.toppings.map((o) => `<label class="check-row filter-row" data-search="${esc(o.name.toLocaleLowerCase("es"))}"><input type="checkbox" value="${o.id}" ${p.optionIds.includes(o.id) ? "checked" : ""}>${o.photo ? `<img src="${esc(o.photo)}" alt="">` : ""}<span class="grow"><b>${esc(o.name)}</b><br><span class="muted">${money(o.price)}</span></span></label>`).join("")}`,
    () => {
      const oldIds = new Set(p.optionIds);
      const allIncluded =
        oldIds.size > 0 &&
        p.optionIds.every((id) => p.priceOverrides?.[id] === 0);
      p.optionIds = [
        ...document.querySelectorAll("#modal input[type=checkbox]:checked"),
      ].map((x) => x.value);
      const prices = {};
      for (const id of p.optionIds) {
        if (p.priceOverrides?.[id] != null) prices[id] = p.priceOverrides[id];
        else if (allIncluded) prices[id] = 0;
      }
      p.priceOverrides = prices;
      audit("Actualizó opciones de fase " + p.name);
      renderConfig();
      toast("Opciones guardadas");
    },
  );
}
function chooseImage(cb) {
  const input = document.createElement("input");
  input.type = "file";
  input.accept = "image/*";
  input.style.display = "none";
  document.body.append(input);
  input.onchange = () => {
    uploadImage(input, cb);
    input.remove();
  };
  input.addEventListener("cancel", () => input.remove());
  input.click();
}
function uploadImage(input, cb) {
  const file = input.files?.[0];
  if (!file) return;
  if (!file.type.startsWith("image/"))
    return alert("Selecciona una fotografía.");
  if (file.size > 25000000) return alert("Elige una foto de menos de 25 MB.");
  const url = URL.createObjectURL(file),
    photo = new Image();
  photo.onerror = () => {
    URL.revokeObjectURL(url);
    alert("No se pudo leer la foto. Prueba con una imagen JPG, PNG o WebP.");
  };
  photo.onload = () => {
    try {
      const scale = Math.min(1, 720 / Math.max(photo.width, photo.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(photo.width * scale));
      canvas.height = Math.max(1, Math.round(photo.height * scale));
      const ctx = canvas.getContext("2d");
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(photo, 0, 0, canvas.width, canvas.height);
      cb(canvas.toDataURL("image/jpeg", 0.78));
      toast("Fotografía guardada");
    } finally {
      URL.revokeObjectURL(url);
    }
  };
  photo.src = url;
}
function changePin(key) {
  if (role !== "admin") return;
  let p = ask("Nuevo PIN de 4 a 8 dígitos");
  if (!/^\d{4,8}$/.test(p || "")) return alert("PIN inválido");
  db[key] = p;
  audit("Actualizó PIN");
  alert("PIN actualizado");
}

function renderClients() {
  $("#content").innerHTML =
    `<div class="panel"><h2>👥 Clientes</h2><input id="nm" placeholder="Nombre"><input id="ph" placeholder="Teléfono"><button class="primary" onclick="addClient()">Agregar</button><div class="scroll"><table class="table">${db.clients.map((x) => `<tr><td>${esc(x.name)}</td><td>${esc(x.phone)}</td></tr>`).join("")}</table></div></div>`;
}
function addClient() {
  let name = $("#nm").value.trim(),
    phone = $("#ph").value.trim();
  if (!name) return alert("Escribe un nombre");
  db.clients.push({ id: uid(), name, phone });
  audit("Cliente " + name);
  render();
}
function renderExpenses() {
  $("#content").innerHTML =
    `<div class="panel"><h2>💸 Gastos</h2><input id="nm" placeholder="Concepto"><input id="amt" type="number" min="0" step=".01" placeholder="Monto"><select id="method"><option>Efectivo</option><option>Transferencia</option><option>Tarjeta</option></select><button class="primary" onclick="addExpense()">Registrar</button><h3>Total: ${money(db.expenses.reduce((a, x) => a + x.amount, 0))}</h3><div class="scroll"><table class="table">${db.expenses.map((x) => `<tr><td>${new Date(x.at).toLocaleDateString("es-MX")}</td><td>${esc(x.name)}</td><td>${esc(x.method)}</td><td>${money(x.amount)}</td></tr>`).join("")}</table></div></div>`;
}
function addExpense() {
  let name = $("#nm").value.trim(),
    amount = Number($("#amt").value),
    method = $("#method").value;
  if (!name || !Number.isFinite(amount) || amount <= 0)
    return alert("Datos inválidos");
  db.expenses.unshift({
    id: uid(),
    at: new Date().toISOString(),
    name,
    amount,
    method,
  });
  audit("Gasto " + name);
  render();
}
function renderDebts() {
  $("#content").innerHTML =
    `<div class="panel"><h2>📒 Fiados y deudas</h2><p class="notice">Registro manual, separado de las ventas.</p><select id="debtor"><option value="">Cliente</option>${db.clients.map((c) => `<option value="${c.id}">${esc(c.name)}</option>`).join("")}</select><input id="amt" type="number" min="0" step=".01" placeholder="Monto"><input id="detail" placeholder="Concepto"><button class="primary" onclick="addDebt()">Registrar</button><div class="scroll"><table class="table">${db.debts.map((x) => `<tr><td>${esc(db.clients.find((c) => c.id === x.clientId)?.name || "Cliente")}</td><td>${esc(x.detail)}</td><td>${money(x.balance)}</td><td><button onclick="payDebt('${x.id}')">Abonar</button></td></tr>`).join("")}</table></div></div>`;
}
function addDebt() {
  let clientId = $("#debtor").value,
    amount = Number($("#amt").value),
    detail = $("#detail").value.trim();
  if (!clientId || !Number.isFinite(amount) || amount <= 0)
    return alert("Datos inválidos");
  db.debts.unshift({
    id: uid(),
    clientId,
    amount,
    balance: amount,
    detail,
    at: new Date().toISOString(),
    payments: [],
  });
  audit("Deuda " + detail);
  render();
}
function payDebt(id) {
  let x = db.debts.find((d) => d.id === id),
    v = prompt("Monto del abono. Pendiente: " + money(x.balance));
  if (v === null) return;
  let n = Number(v);
  if (!Number.isFinite(n) || n <= 0 || n > x.balance)
    return alert("Monto inválido");
  x.balance = Math.round((x.balance - n) * 100) / 100;
  x.payments.push({ at: new Date().toISOString(), amount: n });
  audit("Abono " + id);
  render();
}
function renderSuppliers() {
  $("#content").innerHTML =
    `<div class="panel"><h2>🏪 Proveedores</h2><input id="nm" placeholder="Proveedor"><input id="ph" placeholder="Teléfono"><input id="notes" placeholder="Qué vende"><button class="primary" onclick="addSupplier()">Agregar</button><div class="scroll"><table class="table">${db.suppliers.map((x) => `<tr><td>${esc(x.name)}</td><td>${esc(x.phone)}</td><td>${esc(x.notes)}</td></tr>`).join("")}</table></div></div>`;
}
function addSupplier() {
  let name = $("#nm").value.trim(),
    phone = $("#ph").value.trim(),
    notes = $("#notes").value.trim();
  if (!name) return alert("Falta nombre");
  db.suppliers.push({ id: uid(), name, phone, notes });
  audit("Proveedor " + name);
  render();
}
function exportSalesCSV() {
  const rows = [
    ["Folio", "Fecha", "Total", "Cancelada"],
    ...db.sales.map((x) => [x.id, x.at, x.total, x.void ? "Sí" : "No"]),
  ];
  const csv = rows
    .map((row) =>
      row.map((v) => '"' + String(v ?? "").replace(/"/g, '""') + '"').join(","),
    )
    .join("\r\n");
  saveTextFile("santo-antojo-ventas.csv", "text/csv", "\ufeff" + csv);
}
function renderReports() {
  let valid = db.sales.filter((x) => !x.void),
    total = valid.reduce((v, x) => v + x.total, 0),
    cost = valid.reduce((v, x) => v + (x.estimatedCost || 0), 0),
    expenses = db.expenses.reduce((v, x) => v + x.amount, 0),
    low = db.inventory.filter((x) => x.stock <= x.min);
  $("#content").innerHTML =
    `<div class="panel"><h2>📊 Resultados e inventario</h2><div class="grid"><div class="panel"><p>Ventas registradas</p><h2>${valid.length}</h2></div><div class="panel"><p>Ingresos</p><h2>${money(total)}</h2></div><div class="panel"><p>Costo estimado de insumos vendidos</p><h2>${money(cost)}</h2></div><div class="panel"><p>Margen bruto estimado</p><h2>${money(total - cost)}</h2></div><div class="panel"><p>Gastos registrados</p><h2>${money(expenses)}</h2></div><div class="panel"><p>Insumos en mínimo</p><h2>${low.length}</h2></div></div>
 <p class="notice">El margen es estimado y depende de que configures TODAS las recetas y costos. No representa utilidad neta ni corte de caja. Las ventas anteriores a V5 no tienen costo de receta registrado.</p>
 <button class="primary" onclick="exportSalesCSV()">Descargar ventas CSV</button><h3>Registro de actividad</h3>${db.audit
   .slice(0, 40)
   .map(
     (x) =>
       `<p class="small">${new Date(x.at).toLocaleString("es-MX")} · ${esc(x.role)} · ${esc(x.msg)}</p>`,
   )
   .join("")}</div>`;
}
function exportData() {
  saveTextFile(
    "santo-antojo-respaldo-" + new Date().toISOString().slice(0, 10) + ".json",
    "application/json",
    JSON.stringify(db, null, 2),
  );
}
function importData(input) {
  const file = input.files?.[0];
  if (!file) return;
  if (file.size > 16000000) {
    alert("El respaldo supera 16 MB.");
    input.value = "";
    return;
  }
  const reader = new FileReader();
  reader.onerror = () => {
    alert("No se pudo leer el archivo. Intenta seleccionarlo otra vez.");
    input.value = "";
  };
  reader.onload = () => {
    let incoming;
    try {
      incoming = normalizeDatabase(JSON.parse(reader.result));
    } catch (error) {
      alert("Respaldo inválido: " + error.message);
      input.value = "";
      return;
    }
    if (
      confirm(
        "El respaldo contiene " +
          incoming.products.length +
          " productos y " +
          incoming.sales.length +
          " ventas. ¿Reemplazar los datos actuales? Exporta tu respaldo actual antes de continuar.",
      )
    ) {
      const previous = db;
      try {
        db = incoming;
        save();
        location.reload();
      } catch (error) {
        db = previous;
      }
    }
    input.value = "";
  };
  reader.readAsText(file);
}
render();


// Santo Antojo 1.3: campañas IA con red vía puente HTTPS nativo.
// ACTUALIZACIONES: se descarga una APK verificada; nunca cambia la base de datos local.
const UPDATE_FEED_STORE = 'santo_antojo_update_feed';
const UPDATE_LAST_CHECK_STORE = 'santo_antojo_update_checked_at';
let lastUpdateInfo = null;
let updateCheckWasSilent = false;
function saveUpdateFeed() {
  const field=document.getElementById('update-feed-url');
  if(!field)return;
  const url=field.value.trim();
  if(url && (!/^https:\/\/[^\s]+$/i.test(url) || !url.endsWith('.json'))) {
    alert('Introduce una dirección HTTPS válida que termine en .json.');return;
  }
  if(url)localStorage.setItem(UPDATE_FEED_STORE,url);
  else localStorage.removeItem(UPDATE_FEED_STORE);
  const status=document.getElementById('update-state');
  if(status)status.textContent=url?'Dirección guardada. Ya puedes buscar versiones nuevas.':'Actualizaciones automáticas desactivadas.';
}
function maybeCheckForAppUpdate() {
  const feed=localStorage.getItem(UPDATE_FEED_STORE);
  const last=Number(localStorage.getItem(UPDATE_LAST_CHECK_STORE)||0);
  if(feed && Date.now()-last>24*60*60*1000) checkForAppUpdate(true);
}
function checkForAppUpdate(silent) {
  const feed=localStorage.getItem(UPDATE_FEED_STORE);
  const status=document.getElementById('update-state');
  if(!feed){if(!silent)alert('Primero guarda tu dirección de actualizaciones en Configurar.');return;}
  if(!window.SantoAndroid || typeof SantoAndroid.checkForUpdates!=='function') {
    if(!silent)alert('Esta función solo está disponible dentro de la app Android.');return;
  }
  updateCheckWasSilent=!!silent;
  if(status)status.textContent='Buscando actualización segura…';
  try {SantoAndroid.checkForUpdates(feed);}catch(e){if(status)status.textContent='No se pudo revisar el servidor.';}
}
function santoUpdateResult(raw) {
  let data;
  try{data=JSON.parse(raw);}catch(e){return;}
  const status=document.getElementById('update-state');
  if(data.error){if(status)status.textContent=data.error;else if(!updateCheckWasSilent)alert(data.error);return;}
  if(data.downloaded){
    if(status)status.textContent='APK descargada y verificada. Abriendo instalador de Android…';
    SantoAndroid.finishUpdateInstall();
    return;
  }
  if(!data.available){
    localStorage.setItem(UPDATE_LAST_CHECK_STORE,String(Date.now()));
    if(status)status.textContent='Tienes la versión más reciente disponible.';
    else if(!updateCheckWasSilent)alert('Santo Antojo ya está actualizado.');
    return;
  }
  lastUpdateInfo=data;
  localStorage.setItem(UPDATE_LAST_CHECK_STORE,String(Date.now()));
  if(status)status.textContent='Nueva versión disponible: '+String(data.versionName)+'.';
  if(confirm('Santo Antojo '+data.versionName+' está disponible. ¿Descargar e instalar ahora? Android solicitará tu aprobación.')){
    if(status)status.textContent='Descargando y verificando APK…';
    SantoAndroid.installVerifiedUpdate(data.apkUrl,data.sha256);
  }
}
const CAMPAIGN_STORE = 'santo_antojo_campaigns_v1';
const CAMPAIGN_ENDPOINT_STORE = 'santo_antojo_campaign_endpoint';
const CAMPAIGN_ACCESS_STORE = 'santo_antojo_campaign_access'; // Acceso de dispositivo; NUNCA es clave OpenAI/Metricool.
const campaignCalls = new Map();
window.santoAndroidResult = (id, status, text) => {
  const job = campaignCalls.get(id); if(!job) return;
  campaignCalls.delete(id); clearTimeout(job.timer);
  let data; try { data = JSON.parse(text); } catch {data={error:'Respuesta inválida del servidor'};}
  if(status < 200 || status >= 300) job.reject(new Error(data.error || `Error HTTP ${status||'de conexión'}`));
  else job.resolve(data);
};
function campaignRequest(path, payload) {
  const endpoint=localStorage.getItem(CAMPAIGN_ENDPOINT_STORE)||'';
  const token=localStorage.getItem(CAMPAIGN_ACCESS_STORE)||'';
  if(!endpoint || !token) return Promise.reject(new Error('Configura el servidor HTTPS y el código de acceso desde ⚙ Servidor IA.'));
  if(!window.SantoAndroid || typeof window.SantoAndroid.campaignPost!=='function')
    return Promise.reject(new Error('Abre Santo Antojo desde el APK Android para conectar al servidor.'));
  return new Promise((resolve,reject)=>{
    const id='req'+uid();
    const timer=setTimeout(()=>{campaignCalls.delete(id);reject(new Error('Tiempo de espera agotado'));},120000);
    campaignCalls.set(id,{resolve,reject,timer});
    try { window.SantoAndroid.campaignPost(id,endpoint,path,token,JSON.stringify(payload)); }
    catch(e) {clearTimeout(timer);campaignCalls.delete(id);reject(new Error('No se pudo abrir la conexión HTTPS'));}
  });
}
function campaignDrafts() {
  try { const a=JSON.parse(localStorage.getItem(CAMPAIGN_STORE)||'[]'); return Array.isArray(a)?a:[]; }
  catch {return [];}
}
function putCampaigns(a) {
  try {localStorage.setItem(CAMPAIGN_STORE,JSON.stringify(a.slice(0,8))); return true;}
  catch(e) { alert('Almacenamiento lleno. Guarda fotos más pequeñas o elimina borradores antiguos.'); return false; }
}
let campaignImage = '';
function compressCampaignImage(dataUrl, width=760, quality=.76) {
  return new Promise((resolve,reject)=>{
    const img=new Image();
    img.onload=()=>{
      const scale=Math.min(1,width/Math.max(img.naturalWidth,img.naturalHeight));
      const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
      const ctx=canvas.getContext('2d'); if(!ctx){reject(new Error('No se puede procesar la imagen'));return;}
      ctx.drawImage(img,0,0,canvas.width,canvas.height);
      resolve(canvas.toDataURL('image/jpeg',quality));
    };img.onerror=()=>reject(new Error('Imagen no válida'));img.src=dataUrl;
  });
}
function campaignImageChanged(input) {
  const file=input.files && input.files[0];if(!file)return;
  if (!/^image\/(jpeg|png|webp)$/.test(file.type)) {alert('Selecciona JPG, PNG o WebP.');return;}
  if (file.size>5*1024*1024) {alert('Selecciona una foto de menos de 5 MB.');return;}
  const reader=new FileReader();
  reader.onload=async()=>{
    try {
      campaignImage=await compressCampaignImage(String(reader.result));
      const el=document.getElementById('campaign-photo-preview');
      if(el)el.innerHTML='<img alt="Foto elegida" style="width:100%;max-height:280px;object-fit:contain;border-radius:12px" src="'+campaignImage+'">';
    } catch(e){alert(e.message);}
  };
  reader.readAsDataURL(file);
}
function renderCampaigns() {
  const drafts=campaignDrafts();const products=db.products||[];
  $('#content').innerHTML=`<div class="panel"><h2>📣 Campañas con IA</h2>
    <p class="muted">Prepara, revisa y guarda anuncios. Nada se publicará sin tu confirmación. Ventas e inventario siguen disponibles sin internet.</p>
    <div class="field"><label>Producto</label><select id="campaign-product">${products.map(p=>`<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('')}</select></div>
    <div class="field"><label>Objetivo</label><select id="campaign-goal"><option value="antojo">Despertar antojo</option><option value="lanzamiento">Presentar producto</option><option value="promocion">Promoción (solo si la describes)</option></select></div>
    <div class="field"><label>Qué quieres anunciar</label><textarea id="campaign-brief" rows="3" placeholder="Destaca las fresas con crema, Raffaello y la experiencia de Santo Antojo"></textarea></div>
    <div class="field"><label>Fotografía del producto (JPG, PNG o WebP)</label><input type="file" accept="image/jpeg,image/png,image/webp" onchange="campaignImageChanged(this)"></div>
    <div id="campaign-photo-preview"></div>
    <div class="row" style="margin-top:14px;flex-wrap:wrap"><button class="primary" id="campaign-generate" onclick="generateCampaign()">✨ Generar campaña</button><button onclick="saveCampaignEndpoint()">⚙ Servidor IA</button></div>
    <p id="campaign-status" class="muted" aria-live="polite">Para usar OpenAI necesitas un servidor HTTPS propio y un código de acceso de dispositivo.</p>
    <section id="campaign-output"></section></div>
    <div class="panel" style="margin-top:16px"><h2>📁 Borradores (${drafts.length})</h2>${drafts.length?drafts.map(d=>`<div class="campaign-draft"><strong>${esc(d.productName)}</strong><small> · ${esc(new Date(d.date).toLocaleString('es-MX'))}</small><div><button onclick="viewCampaign('${esc(d.id)}')">Ver y programar</button> <button onclick="deleteCampaign('${esc(d.id)}')">Eliminar</button></div></div>`).join(''):'<p class="muted">Todavía no hay campañas guardadas.</p>'}</div>`;
}
function saveCampaignEndpoint() {
  const old=localStorage.getItem(CAMPAIGN_ENDPOINT_STORE)||'';
  const v=prompt('URL base HTTPS de tu servidor (ejemplo: https://campanas.tudominio.mx). Nunca pegues una clave API:',old);
  if(v===null)return;
  if(v.trim() && !/^https:\/\/[a-z0-9.-]+\/?$/i.test(v.trim())) {alert('Escribe una URL HTTPS sin ruta, puerto ni parámetros.');return;}
  const key=prompt('Código de acceso del dispositivo, configurado como SANTO_CAMPAIGN_TOKEN en tu servidor. NO es tu clave de OpenAI ni de Metricool:',localStorage.getItem(CAMPAIGN_ACCESS_STORE)||'');
  if(key===null)return;
  if(v.trim() && key.length<24){alert('El código de acceso debe tener al menos 24 caracteres aleatorios.');return;}
  localStorage.setItem(CAMPAIGN_ENDPOINT_STORE,v.trim().replace(/\/$/,''));
  if(v.trim())localStorage.setItem(CAMPAIGN_ACCESS_STORE,key); else localStorage.removeItem(CAMPAIGN_ACCESS_STORE);
  alert(v.trim()?'Servidor configurado; prueba generando una campaña.':'Servidor eliminado.');
}
async function generateCampaign() {
  const p=db.products.find(x=>x.id===$('#campaign-product').value);if(!p)return;
  const goal=$('#campaign-goal').value,brief=$('#campaign-brief').value.trim();
  const status=$('#campaign-status'),btn=$('#campaign-generate');btn.disabled=true;
  status.textContent='Generando propuesta de texto mediante OpenAI...';
  try{
    const result=await campaignRequest('/campaign',{productName:p.name,price:p.price,goal,brief});
    if(typeof result.title!=='string'||typeof result.copy!=='string')throw Error('Respuesta incompleta');
    const item={id:'c'+uid(),date:new Date().toISOString(),productName:p.name,goal,brief,
      title:result.title.slice(0,160),copy:result.copy.slice(0,1500),hashtags:String(result.hashtags||'').slice(0,300),
      image:campaignImage,generatedImage:false,published:false};
    const list=campaignDrafts();list.unshift(item);if(!putCampaigns(list))return;
    showCampaign(item);status.textContent='Borrador guardado. Puedes generar una imagen publicitaria opcionalmente.';
  }catch(e){status.textContent='No se pudo generar la campaña: '+e.message;}
  finally{btn.disabled=false;}
}
function updateCampaign(item){let drafts=campaignDrafts();drafts=drafts.map(x=>x.id===item.id?item:x);return putCampaigns(drafts);}
function showCampaign(d) {
  const out=$('#campaign-output');if(!out)return;
  const canPublish=!d.published;
  out.innerHTML=`<div class="campaign-preview"><h3>👀 Vista previa · ${esc(d.productName)}</h3>
    ${d.image?`<img src="${d.image}" alt="Producto" style="width:100%;max-height:350px;object-fit:contain;border-radius:12px">`:'<p class="muted">Sin fotografía. Añade una foto para el anuncio de Instagram.</p>'}
    <h3>${esc(d.title)}</h3><p style="white-space:pre-wrap">${esc(d.copy)}</p><p>${esc(d.hashtags)}</p>
    <div class="row" style="flex-wrap:wrap"><button onclick="copyCampaign('${esc(d.id)}')">📋 Copiar texto</button>
    ${!d.published?`<button onclick="editCampaignText('${esc(d.id)}')">✏️ Editar texto</button>`:''}
    ${d.image?`<button id="campaign-edit-image" onclick="generateCampaignImage('${esc(d.id)}')">🎨 Crear imagen con IA</button>`:''}
    <button onclick="renderCampaigns()">Volver</button></div>
    <p id="campaign-preview-status" class="muted">${d.published?'Ya fue enviada a Metricool: revisa el planificador antes de volver a programarla.':'La imagen generada con IA puede cambiar pequeños detalles del producto; revísala antes de aprobar.'}</p>
    ${canPublish?`<div style="margin-top:16px;border-top:1px solid #ddd;padding-top:12px">
      <h3>📅 Programar en redes (requiere Metricool API)</h3>
      <div class="field"><label>Fecha y hora futuras, Huaniqueo / Ciudad de México</label><input type="datetime-local" id="campaign-when"></div>
      <div class="row" style="flex-wrap:wrap"><label><input type="checkbox" id="campaign-instagram" checked> Instagram</label> <label><input type="checkbox" id="campaign-facebook" checked> Facebook</label></div>
      <p class="muted">Al aprobar, la foto se aloja mediante tu servidor y Metricool intentará programar una publicación para las redes elegidas.</p>
      <button class="primary" id="campaign-schedule-btn" onclick="scheduleCampaign('${esc(d.id)}')">✅ Aprobar y programar</button>
    </div>`:''}</div>`;
}
async function generateCampaignImage(id) {
  const d=campaignDrafts().find(x=>x.id===id);if(!d||!d.image)return;
  const status=$('#campaign-preview-status'),btn=$('#campaign-edit-image');btn.disabled=true;
  status.textContent='Editando fotografía con IA. Puede generar un costo en tu cuenta OpenAI...';
  try {
    const result=await campaignRequest('/image',{image:d.image,productName:d.productName,brief:d.brief,title:d.title});
    if(!/^data:image\/(jpeg|png|webp);base64,/.test(result.image||''))throw Error('El servidor no devolvió una imagen');
    // Comprímela antes de guardarla en el almacenamiento local Android.
    d.image=await compressCampaignImage(result.image,950,.82);
    d.generatedImage=true; if(updateCampaign(d))showCampaign(d);
  }catch(e){status.textContent='No se pudo crear imagen con IA: '+e.message;}
  finally{btn.disabled=false;}
}
async function scheduleCampaign(id) {
  const d=campaignDrafts().find(x=>x.id===id);if(!d||d.published)return;
  const status=$('#campaign-preview-status');
  const when=$('#campaign-when').value;
  const providers=['instagram','facebook'].filter(net=>$('#campaign-'+net)?.checked);
  if(!d.image){status.textContent='Para publicar simultáneamente necesitas añadir primero una foto del producto.';return;}
  if(!when||providers.length===0){status.textContent='Selecciona la fecha futura y al menos una red.';return;}
  const date= new Date(when);if(!Number.isFinite(date.getTime())||date.getTime()<=Date.now()+120000){status.textContent='Elige una hora posterior, al menos 2 minutos en el futuro.';return;}
  if(!confirm(`¿Aprobar y programar en ${providers.join(' y ')} para ${when.replace('T',' ')}? La foto quedará pública en tu servidor.`))return;
  const btn=$('#campaign-schedule-btn');btn.disabled=true;
  try{
    status.textContent='Preparando fotografía para Metricool...';
    const media=await campaignRequest('/media',{image:d.image});
    status.textContent='Programando redes seleccionadas...';
    const result=await campaignRequest('/schedule',{text:[d.title,d.copy,d.hashtags].filter(Boolean).join('\n\n'),when,providers,imageUrl:media.url});
    d.published=true;d.metricoolId=String(result.id||'');d.publishedAt=new Date().toISOString();
    updateCampaign(d);showCampaign(d);$('#campaign-preview-status').textContent='Programación solicitada correctamente a Metricool. Confirma el estado en su planificador.';
  }catch(e){status.textContent='No se pudo programar: '+e.message+' (no se confirmó publicación)';btn.disabled=false;}
}
function editCampaignText(id){
  const d=campaignDrafts().find(x=>x.id===id);if(!d||d.published)return;
  const title=prompt('Título del anuncio:',d.title);if(title===null)return;
  const copy=prompt('Texto del anuncio:',d.copy);if(copy===null)return;
  const hashtags=prompt('Hashtags:',d.hashtags);if(hashtags===null)return;
  if(!title.trim()||!copy.trim()){alert('El anuncio debe incluir título y texto.');return;}
  d.title=title.trim().slice(0,160);d.copy=copy.trim().slice(0,1500);d.hashtags=hashtags.trim().slice(0,300);
  if(updateCampaign(d))showCampaign(d);
}
function viewCampaign(id){const d=campaignDrafts().find(x=>x.id===id);if(d){showCampaign(d);$('#campaign-output').scrollIntoView({behavior:'smooth'});}}
function deleteCampaign(id){if(!confirm('¿Eliminar este borrador?'))return;putCampaigns(campaignDrafts().filter(x=>x.id!==id));renderCampaigns();}
function copyCampaign(id){const d=campaignDrafts().find(x=>x.id===id);if(!d)return;const t=[d.title,d.copy,d.hashtags].filter(Boolean).join('\n\n');if(navigator.clipboard?.writeText)navigator.clipboard.writeText(t).then(()=>alert('Texto copiado.')).catch(()=>prompt('Copia el texto:',t));else prompt('Copia el texto:',t);}
