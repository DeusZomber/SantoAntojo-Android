package mx.santoantojo.pos;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;

/** Grants Android's installer temporary read-only access to a verified APK. */
public class UpdateFileProvider extends ContentProvider {
    private static final String NAME = "santo-antojo-actualizacion.apk";
    @Override public boolean onCreate() { return true; }
    private boolean accepted(Uri uri) {
        return "mx.santoantojo.pos.updates".equals(uri.getAuthority()) &&
            ("/" + NAME).equals(uri.getPath());
    }
    @Override public String getType(Uri uri) {
        return accepted(uri) ? "application/vnd.android.package-archive" : null;
    }
    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!accepted(uri) || !"r".equals(mode)) throw new FileNotFoundException();
        File f = new File(getContext().getCacheDir(), NAME);
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        if (!accepted(uri)) return null;
        File f = new File(getContext().getCacheDir(), NAME);
        String[] cols = projection == null ? new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE} : projection;
        MatrixCursor result = new MatrixCursor(cols);
        Object[] values = new Object[cols.length];
        for (int i = 0; i < cols.length; i++) {
            if (OpenableColumns.DISPLAY_NAME.equals(cols[i])) values[i] = NAME;
            else if (OpenableColumns.SIZE.equals(cols[i])) values[i] = f.length();
        }
        result.addRow(values); return result;
    }
    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { throw new UnsupportedOperationException(); }
}