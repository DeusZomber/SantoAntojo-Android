package mx.santoantojo.pos;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.print.PrintManager;
import android.webkit.*;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View;
import java.io.OutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.ByteArrayOutputStream;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.io.File;
import java.io.FileOutputStream;
import java.security.MessageDigest;
import java.util.Locale;
import android.os.Build;
import android.provider.Settings;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

/** Offline WebView host. User files use Android's document picker, without broad storage access. */
public class MainActivity extends Activity {
    private static final int PICK_FILE = 42, SAVE_FILE = 43;
    private static final String START = "file:///android_asset/index.html";
    private WebView web, printWeb;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingFile;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);
        getWindow().setStatusBarColor(0xff76213e);
        getWindow().setNavigationBarColor(0xff76213e);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setBuiltInZoomControls(false);
        settings.setTextZoom(100);
        web.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                // Keep the JavaScript bridge restricted to the bundled app.
                return !START.equals(r.getUrl().toString());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri uri = r.getUrl();
                String scheme = uri.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    return new WebResourceResponse("text/plain", "UTF-8", new java.io.ByteArrayInputStream(new byte[0]));
                }
                return super.shouldInterceptRequest(v, r);
            }
            @Override public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Santo Antojo")
                    .setMessage("No se pudo abrir la pantalla. Tus datos siguen guardados en el dispositivo.")
                    .setPositiveButton("Reintentar", (d, w) -> web.loadUrl(START)).show();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsAlert(WebView v, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setTitle("Santo Antojo").setMessage(message)
                    .setPositiveButton("Aceptar", (d,w)->result.confirm()).setOnCancelListener(d->result.cancel()).show();
                return true;
            }
            @Override public boolean onJsConfirm(WebView v, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setTitle("Santo Antojo").setMessage(message)
                    .setPositiveButton("Continuar", (d,w)->result.confirm())
                    .setNegativeButton("Cancelar", (d,w)->result.cancel()).setOnCancelListener(d->result.cancel()).show();
                return true;
            }
            @Override public boolean onJsPrompt(WebView v, String url, String message, String value, JsPromptResult result) {
                EditText input = new EditText(MainActivity.this);
                input.setSingleLine(false); input.setMaxLines(5); input.setText(value); input.setSelectAllOnFocus(true);
                input.setPadding(32,24,32,24);
                new AlertDialog.Builder(MainActivity.this).setTitle("Santo Antojo").setMessage(message).setView(input)
                    .setPositiveButton("Guardar", (d,w)->result.confirm(input.getText().toString()))
                    .setNegativeButton("Cancelar", (d,w)->result.cancel()).setOnCancelListener(d->result.cancel()).show();
                return true;
            }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                String[] types = params.getAcceptTypes();
                pick.setType(types.length == 1 && types[0].startsWith("image/") ? types[0] : "*/*");
                pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { startActivityForResult(pick, PICK_FILE); }
                catch (Exception ex) { fileCallback.onReceiveValue(null); fileCallback = null; message("No se pudo abrir el selector de archivos."); }
                return true;
            }
        });
        web.addJavascriptInterface(new DeviceFiles(), "SantoAndroid");
        web.loadUrl(START);
    }

    private static final String UPDATE_FILE = "santo-antojo-actualizacion.apk";
    private String pendingUpdateHash = null;

    // HTTPS only. This stops a feed from redirecting to an unencrypted download.
    private URL safeHttps(String raw) throws Exception {
        if (raw == null || raw.length() > 1600) throw new IllegalArgumentException("Dirección demasiado larga");
        URL url = new URL(raw);
        if (!"https".equalsIgnoreCase(url.getProtocol()) || url.getUserInfo() != null ||
            url.getRef() != null || (url.getPort() != -1 && url.getPort() != 443) ||
            url.getHost() == null || url.getHost().isEmpty())
            throw new IllegalArgumentException("Solo se admiten direcciones HTTPS");
        return url;
    }
    private HttpURLConnection openUpdateConnection(String raw) throws Exception {
        URL url = safeHttps(raw);
        for (int hop = 0; hop <= 5; hop++) {
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setInstanceFollowRedirects(false);
            conn.setRequestProperty("User-Agent", "SantoAntojoUpdater/1.4");
            int status = conn.getResponseCode();
            if (status == 301 || status == 302 || status == 303 || status == 307 || status == 308) {
                String next = conn.getHeaderField("Location");
                url = safeHttps(new URL(url, next).toExternalForm());
                conn.disconnect();
                continue;
            }
            if (status != 200) {
                conn.disconnect();
                throw new java.io.IOException("El servidor respondió " + status);
            }
            return conn;
        }
        throw new java.io.IOException("Demasiadas redirecciones");
    }
    private byte[] readLimited(InputStream in, int limit) throws Exception {
        try (InputStream input = in; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = input.read(buffer)) != -1) {
                if (output.size() + n > limit) throw new java.io.IOException("Respuesta demasiado grande");
                output.write(buffer, 0, n);
            }
            return output.toByteArray();
        }
    }
    private void updateResult(JSONObject obj) {
        runOnUiThread(() -> {
            if (web != null) web.evaluateJavascript("window.santoUpdateResult && window.santoUpdateResult(" +
                JSONObject.quote(obj.toString()) + ")", null);
        });
    }
    private JSONObject updateError(String error) {
        JSONObject result = new JSONObject();
        try { result.put("error", error); } catch (Exception ignored) { }
        return result;
    }
    private int installedVersion() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode; }
        catch (Exception ignored) { return 0; }
    }
    private void launchUpdateInstaller() {
        File apk = new File(getCacheDir(), UPDATE_FILE);
        if (!apk.isFile()) { message("No se encontró la actualización descargada."); return; }
        try {
            if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                pendingUpdateHash = "awaiting-permission";
                message("Permite instalar actualizaciones de Santo Antojo y vuelve a esta pantalla.");
                Intent settings = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName()));
                startActivity(settings);
                return;
            }
            pendingUpdateHash = null;
            Uri content = Uri.parse("content://mx.santoantojo.pos.updates/" + UPDATE_FILE);
            Intent install = new Intent(Intent.ACTION_VIEW);
            install.setDataAndType(content, "application/vnd.android.package-archive");
            install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(install);
        } catch (Exception e) { message("No se pudo abrir el instalador de Android."); }
    }
    @Override protected void onResume() {
        super.onResume();
        if ("awaiting-permission".equals(pendingUpdateHash) && Build.VERSION.SDK_INT >= 26 &&
            getPackageManager().canRequestPackageInstalls()) launchUpdateInstaller();
    }

    private void message(String text) { Toast.makeText(this, text, Toast.LENGTH_LONG).show(); }

    public final class DeviceFiles {
        @JavascriptInterface public String getVersionInfo() {
            return "{\"versionCode\":" + installedVersion() + ",\"versionName\":\"1.4\"}";
        }
        @JavascriptInterface public void checkForUpdates(String manifestUrl) {
            new Thread(() -> {
                HttpURLConnection conn = null;
                try {
                    conn = openUpdateConnection(manifestUrl);
                    byte[] body = readLimited(conn.getInputStream(), 65536);
                    JSONObject feed = new JSONObject(new String(body, StandardCharsets.UTF_8));
                    int code = feed.getInt("versionCode");
                    String name = feed.getString("versionName");
                    String apkUrl = feed.getString("apkUrl");
                    String hash = feed.getString("sha256");
                    if (code < 1 || code > 100000000 || name.length() > 40 ||
                        !hash.matches("(?i)[0-9a-f]{64}") ||
                        !safeHttps(apkUrl).getPath().toLowerCase(Locale.ROOT).endsWith(".apk"))
                        throw new IllegalArgumentException("Datos de actualización inválidos");
                    JSONObject result = new JSONObject();
                    result.put("versionCode", code);
                    result.put("versionName", name);
                    result.put("apkUrl", apkUrl);
                    result.put("sha256", hash.toLowerCase(Locale.ROOT));
                    result.put("installedVersionCode", installedVersion());
                    result.put("available", code > installedVersion());
                    updateResult(result);
                } catch (Exception ex) { updateResult(updateError("No se pudo consultar el servidor de actualizaciones.")); }
                finally { if (conn != null) conn.disconnect(); }
            }).start();
        }
        @JavascriptInterface public void installVerifiedUpdate(String downloadUrl, String expectedSha256) {
            if (expectedSha256 == null || !expectedSha256.matches("(?i)[0-9a-f]{64}")) {
                updateResult(updateError("Falta una huella SHA-256 válida.")); return;
            }
            new Thread(() -> {
                HttpURLConnection conn = null;
                File staged = new File(getCacheDir(), UPDATE_FILE + ".tmp.apk");
                try {
                    if (!safeHttps(downloadUrl).getPath().toLowerCase(Locale.ROOT).endsWith(".apk"))
                        throw new IllegalArgumentException("URL APK inválida");
                    conn = openUpdateConnection(downloadUrl);
                    MessageDigest digest = MessageDigest.getInstance("SHA-256");
                    long total = 0;
                    try (InputStream in = conn.getInputStream(); FileOutputStream out = new FileOutputStream(staged)) {
                        byte[] bytes = new byte[16384]; int n;
                        while ((n = in.read(bytes)) != -1) {
                            total += n;
                            if (total > 150L * 1024L * 1024L) throw new java.io.IOException("APK demasiado grande");
                            digest.update(bytes, 0, n);
                            out.write(bytes, 0, n);
                        }
                    }
                    if (total < 10000) throw new java.io.IOException("APK incompleta");
                    StringBuilder actual = new StringBuilder();
                    for (byte b : digest.digest()) actual.append(String.format(Locale.ROOT, "%02x", b & 0xff));
                    if (!actual.toString().equalsIgnoreCase(expectedSha256))
                        throw new SecurityException("La descarga no coincide con la firma SHA-256 del archivo esperado");
                    PackageInfo candidate = getPackageManager().getPackageArchiveInfo(staged.getAbsolutePath(), 0);
                    if (candidate == null || !getPackageName().equals(candidate.packageName) ||
                        candidate.versionCode <= installedVersion())
                        throw new SecurityException("La APK no corresponde a una nueva versión de Santo Antojo");
                    File destination = new File(getCacheDir(), UPDATE_FILE);
                    if (destination.exists() && !destination.delete()) throw new java.io.IOException("No se pudo sustituir la APK");
                    if (!staged.renameTo(destination)) throw new java.io.IOException("No se pudo preparar la APK");
                    updateResult(new JSONObject().put("downloaded", true));
                } catch (Exception e) {
                    staged.delete();
                    updateResult(updateError("No se pudo verificar la APK. No se instalará."));
                } finally { if (conn != null) conn.disconnect(); }
            }).start();
        }
        @JavascriptInterface public void finishUpdateInstall() {
            runOnUiThread(() -> launchUpdateInstaller());
        }
        // HTTPS nativo: WebView sobre file:// no puede usar fetch externo con CORS.
        // La clave OpenAI y el token Metricool jamás se almacenan en Android.
        @JavascriptInterface public void campaignPost(String id, String endpoint, String path, String token, String json) {
            if (id == null || !id.matches("[a-zA-Z0-9_-]{1,48}")) return;
            new Thread(() -> {
                int status = 0;
                String result = "{\"error\":\"No se pudo conectar al servidor\"}";
                HttpURLConnection conn = null;
                try {
                    if (endpoint == null || endpoint.length() > 300 || token == null || token.length() > 512 ||
                        json == null || json.length() > 9000000 ||
                        !("/campaign".equals(path) || "/image".equals(path) ||
                          "/media".equals(path) || "/schedule".equals(path)))
                        throw new IllegalArgumentException("Configuración o solicitud inválida");
                    URL base = new URL(endpoint);
                    if (!"https".equalsIgnoreCase(base.getProtocol()) || base.getUserInfo() != null ||
                        base.getRef() != null || !(base.getPort() == -1 || base.getPort() == 443) ||
                        !base.getPath().matches("/?"))
                        throw new IllegalArgumentException("Se requiere una dirección HTTPS de servidor sin ruta");
                    URL target = new URL(base.getProtocol(), base.getHost(), base.getPort(), path);
                    conn = (HttpURLConnection) target.openConnection();
                    conn.setInstanceFollowRedirects(false);
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(115000);
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    conn.setRequestProperty("Authorization", "Bearer " + token);
                    byte[] request = json.getBytes(StandardCharsets.UTF_8);
                    conn.setFixedLengthStreamingMode(request.length);
                    try (OutputStream out = conn.getOutputStream()) { out.write(request); }
                    status = conn.getResponseCode();
                    InputStream in = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
                    if (in != null) {
                        try (InputStream input = in; ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                            byte[] buf = new byte[8192]; int n;
                            while ((n = input.read(buf)) != -1) {
                                if (buffer.size() + n > 12000000) throw new java.io.IOException("Respuesta demasiado grande");
                                buffer.write(buf, 0, n);
                            }
                            result = buffer.toString("UTF-8");
                        }
                    }
                } catch (Exception ex) {
                    status = 0;
                    result = "{\"error\":\"" + (ex instanceof IllegalArgumentException ?
                        "Configuración de servidor no válida" : "Error de conexión HTTPS") + "\"}";
                } finally { if (conn != null) conn.disconnect(); }
                final int code = status;
                final String response = result;
                runOnUiThread(() -> {
                    if (web == null) return;
                    web.evaluateJavascript("window.santoAndroidResult && window.santoAndroidResult("+
                        JSONObject.quote(id)+","+code+","+JSONObject.quote(response)+")", null);
                });
            }).start();
        }
        @JavascriptInterface public void saveText(String name, String mime, String content) {
            runOnUiThread(() -> {
                if (pendingFile != null) { message("Termina de guardar el archivo anterior."); return; }
                if (content == null || content.length() > 16000000) { message("El archivo es demasiado grande."); return; }
                if (!"application/json".equals(mime) && !"text/csv".equals(mime)) return;
                pendingFile = content;
                Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                save.addCategory(Intent.CATEGORY_OPENABLE); save.setType(mime);
                save.putExtra(Intent.EXTRA_TITLE, name.replaceAll("[^a-zA-Z0-9._-]", "_"));
                try { startActivityForResult(save, SAVE_FILE); }
                catch (Exception ex) { pendingFile = null; message("No se pudo abrir Guardar archivo. Inténtalo otra vez."); }
            });
        }
        @JavascriptInterface public void printHtml(String html) {
            runOnUiThread(() -> {
                if (html == null || html.length() > 1000000) return;
                if (printWeb != null) printWeb.destroy();
                printWeb = new WebView(MainActivity.this);
                printWeb.getSettings().setJavaScriptEnabled(false);
                printWeb.setWebViewClient(new WebViewClient() {
                    boolean sent = false;
                    @Override public void onPageFinished(WebView v, String url) {
                        if (sent) return; sent = true;
                        try { ((PrintManager)getSystemService(PRINT_SERVICE)).print("Santo Antojo - Ticket", v.createPrintDocumentAdapter("Santo Antojo"), null); }
                        catch (Exception e) { message("No se pudo imprimir. Revisa el servicio de impresión de Android."); }
                    }
                });
                printWeb.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            });
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            fileCallback = null;
        } else if (request == SAVE_FILE) {
            final String content = pendingFile; pendingFile = null;
            if (result != RESULT_OK || data == null || data.getData() == null || content == null) return;
            final Uri uri = data.getData();
            new Thread(() -> {
                try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                    if (out == null) throw new java.io.IOException("No output");
                    out.write(content.getBytes(StandardCharsets.UTF_8));
                    runOnUiThread(()->message("Archivo guardado correctamente."));
                } catch (Exception e) { runOnUiThread(()->message("No se pudo guardar el archivo. Inténtalo en otra carpeta.")); }
            }).start();
        }
    }
    @Override public void onBackPressed() {
        web.evaluateJavascript("window.handleBack ? handleBack() : false", result -> {
            if (!"true".equals(result)) new AlertDialog.Builder(this).setTitle("Santo Antojo")
                .setMessage("¿Salir de la aplicación?").setPositiveButton("Salir",(d,w)->finish())
                .setNegativeButton("Seguir aquí",null).show();
        });
    }
    @Override protected void onDestroy() {
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        if (printWeb != null) printWeb.destroy();
        web.removeJavascriptInterface("SantoAndroid"); web.destroy();
        super.onDestroy();
    }
}
